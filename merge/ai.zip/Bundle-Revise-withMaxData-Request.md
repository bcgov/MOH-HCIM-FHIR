# Revise-withMaxData-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Revise-withMaxData-Request**

## Example Bundle: Revise-withMaxData-Request



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Revise-withMaxData-Request",
  "meta" : {
    "profile" : ["http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-revise-request-bundle"]
  },
  "type" : "collection",
  "timestamp" : "2023-01-23T14:02:15.7695447-08:00",
  "link" : [{
    "relation" : "self",
    "url" : "urn:uuid:1d822cfb-c6a5-43db-ac7e-277234bceb2a"
  }],
  "entry" : [{
    "fullUrl" : "urn:uuid:e12213c8-9351-4a9b-94cb-54d3710be5b4",
    "resource" : {
      "resourceType" : "Parameters",
      "id" : "6426876c-8118-4020-8364-7021d0a1ec23",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-in"]
      },
      "parameter" : [{
        "name" : "messageId",
        "valueString" : "f95c3be0-b6ed-4aec-b969-7bc7da904315"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:112a2ba8-c3c9-4b08-8cfd-f025b85b3e0c",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "Revise-withMaxData-Request-Patient",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_Revise-withMaxData-Request-Patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient Revise-withMaxData-Request-Patient</b></p><a name=\"Revise-withMaxData-Request-Patient\"> </a><a name=\"hcRevise-withMaxData-Request-Patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Geraldine Celestine Iye Banek  Female, DoB: 1956-12-17 ( Jurisdictional health number (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Known status of Patient\">Deceased:</td><td colspan=\"3\">2008-10-26</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li>Account number/2B6F8GN410H1T27NPE (use: official, )</li><li>Account number/Y4DCP5VK29F31R80O8K2O08D5WAU2K950U40D8 (use: secondary, )</li><li>Account number/0EZFV8L7L7E1W9UF9AB3Z (use: secondary, )</li><li>Account number/2281UM0D8528TIVRW5FF4ESNK53N9KO (use: secondary, )</li><li>Account number/JDU70IH8L8575631A39QQMA0DQ7N3DS4 (use: secondary, )</li><li>Account number/154G21E7EK1BT06K72JIM5LE8M0VK09F20A4 (use: secondary, )</li><li>Account number/R8ZNY8I1JI98M15K634C6LOU15375PA (use: secondary, )</li><li>Account number/6M4S730KM98FJ954A2Z981NQLVWTWZ (use: secondary, )</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: 8195411094(Mobile)</li><li>ph: 9847273917(Home)</li><li>ph: 4328811019(Work)</li><li><a href=\"mailto:Bly.Beaule@cgi.com\">Bly.Beaule@cgi.com</a></li><li><a href=\"mailto:Elisabeth.Mrotz@cgi.com\">Elisabeth.Mrotz@cgi.com</a></li><li><a href=\"mailto:Whitney.Holway@cgi.com\">Whitney.Holway@cgi.com</a></li><li>48610 Hilltop street Waukesha BC CA </li><li>8547 Green hill road Ansonville BC CA </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "AN"
          }]
        },
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-vpp-cer-source-patient-id",
        "value" : "2B6F8GN410H1T27NPE"
      },
      {
        "use" : "secondary",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "AN"
          }]
        },
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-vpp-vgh-source-patient-id",
        "value" : "Y4DCP5VK29F31R80O8K2O08D5WAU2K950U40D8"
      },
      {
        "use" : "secondary",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "AN"
          }]
        },
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-vpp-phc-source-patient-id",
        "value" : "0EZFV8L7L7E1W9UF9AB3Z"
      },
      {
        "use" : "secondary",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "AN"
          }]
        },
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-vpp-fph-source-patient-id",
        "value" : "2281UM0D8528TIVRW5FF4ESNK53N9KO"
      },
      {
        "use" : "secondary",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "AN"
          }]
        },
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-vpp-cw-source-patient-id",
        "value" : "JDU70IH8L8575631A39QQMA0DQ7N3DS4"
      },
      {
        "use" : "secondary",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "AN"
          }]
        },
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-vpp-lion-source-patient-id",
        "value" : "154G21E7EK1BT06K72JIM5LE8M0VK09F20A4"
      },
      {
        "use" : "secondary",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "AN"
          }]
        },
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-vpp-pr-source-patient-id",
        "value" : "R8ZNY8I1JI98M15K634C6LOU15375PA"
      },
      {
        "use" : "secondary",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "AN"
          }]
        },
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-vpp-bcca-source-patient-id",
        "value" : "6M4S730KM98FJ954A2Z981NQLVWTWZ"
      },
      {
        "use" : "official",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "JHN"
          }]
        },
        "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-nb-patient-healthcare-id",
        "value" : "54X3KSPOCH235SDF42WQK6"
      }],
      "name" : [{
        "use" : "usual",
        "family" : "Banek",
        "given" : ["Geraldine", "Celestine", "Iye"]
      },
      {
        "use" : "official",
        "family" : "Coad",
        "given" : ["Jervis", "Wilu", "Jules"]
      },
      {
        "use" : "nickname",
        "given" : ["Theodore"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "8195411094",
        "use" : "mobile"
      },
      {
        "system" : "phone",
        "value" : "9847273917",
        "use" : "home"
      },
      {
        "system" : "phone",
        "value" : "4328811019",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "Bly.Beaule@cgi.com",
        "use" : "mobile"
      },
      {
        "system" : "email",
        "value" : "Elisabeth.Mrotz@cgi.com",
        "use" : "home"
      },
      {
        "system" : "email",
        "value" : "Whitney.Holway@cgi.com",
        "use" : "work"
      }],
      "gender" : "female",
      "birthDate" : "1956-12-17",
      "deceasedDateTime" : "2008-10-26",
      "_deceasedDateTime" : {
        "extension" : [{
          "extension" : [{
            "url" : "deathVerifiedFlag",
            "valueBoolean" : true
          }],
          "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-verified-flag-extension"
        }]
      },
      "address" : [{
        "type" : "physical",
        "line" : ["48610 Hilltop street"],
        "city" : "Waukesha",
        "state" : "BC",
        "country" : "CA"
      },
      {
        "type" : "postal",
        "line" : ["8547 Green hill road"],
        "city" : "Ansonville",
        "state" : "BC",
        "country" : "CA"
      }]
    }
  }]
}

```
