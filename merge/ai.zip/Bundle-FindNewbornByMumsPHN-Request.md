# FindNewbornByMumsPHN-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FindNewbornByMumsPHN-Request**

## Example Bundle: FindNewbornByMumsPHN-Request



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FindNewbornByMumsPHN-Request",
  "meta" : {
    "profile" : ["http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-find-candidates-request-bundle"]
  },
  "type" : "collection",
  "timestamp" : "2023-01-23T13:58:38.959895-08:00",
  "link" : [{
    "relation" : "self",
    "url" : "urn:uuid:61a241a9-9d87-426d-ac21-548e1b976af3"
  }],
  "entry" : [{
    "fullUrl" : "urn:uuid:b46f78e1-cfa1-41a6-ba9c-fafe6822791a",
    "resource" : {
      "resourceType" : "Parameters",
      "id" : "FindBabiesByMumsPHN-Parameters",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-in"]
      },
      "parameter" : [{
        "name" : "messageId",
        "valueString" : "9acccdc8-b4d0-4ac7-9f10-80d0c80136e4"
      },
      {
        "name" : "identifiersOnly",
        "valueBoolean" : false
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:e7ae452f-9076-4cd6-958f-1d1c55d34c38",
    "resource" : {
      "resourceType" : "RelatedPerson",
      "id" : "FindBabiesByMumsPHN-RelatedPerson",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RelatedPerson_FindBabiesByMumsPHN-RelatedPerson\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RelatedPerson FindBabiesByMumsPHN-RelatedPerson</b></p><a name=\"FindBabiesByMumsPHN-RelatedPerson\"> </a><a name=\"hcFindBabiesByMumsPHN-RelatedPerson\"> </a><p><b>identifier</b>: <code>https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id</code>/9999999999</p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&amp;canonical=http://hl7.org/fhir/ca/baseline/Patient/e418862f-1759-42de-98a9-00433a779e9b\">Patient/e418862f-1759-42de-98a9-00433a779e9b</a></p><p><b>relationship</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleCode NMTH}\">natural mother</span></p></div>"
      },
      "identifier" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
          "valueCode" : "active"
        }],
        "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id",
        "value" : "9999999999"
      }],
      "patient" : {
        "reference" : "Patient/e418862f-1759-42de-98a9-00433a779e9b"
      },
      "relationship" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
          "code" : "NMTH"
        }]
      }]
    }
  }]
}

```
