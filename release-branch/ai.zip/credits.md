# Credits - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* **Credits**

## Credits

This specification was written and built by:

* BC Ministry of Health (Laura Kingcott)
* CGI (Jonathan Wiebe, Patrick Weckermann, Scott Branton, Byron Lundstrom, Camille Estival)
* Constable Consulting (Lorraine Constable)
* Duteau Design (Jean Duteau)

