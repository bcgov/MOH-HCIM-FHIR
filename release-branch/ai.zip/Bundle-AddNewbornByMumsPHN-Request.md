# AddNewbornByMumsPHN-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AddNewbornByMumsPHN-Request**

## Example Bundle: AddNewbornByMumsPHN-Request

This is an example of an AddPatient Operation, adding a newborn.

The **first** resource in the Bundle is a Parameter resource (MetadataParametersIn) which has the message ID and the message data and time.

The **second** resource is a Patient (ClientRegistryPatient) which represents the newborn. The Identifier is of SRI type as a PHN hasn't been assigned yet. The fullUrl of this Patient is a randomly generated UUID which is used to link the Patient to the RelatedPerson resource within the Bundle.

The **third** resource is a RelatedPerson. This resource represents the mother and the mother's PHN is in the Identifier. The patient.reference is the fullUrl of the newborn Patient resource (see **second** resource above) within this Bundle. Lastly the relationship code is NMTH.



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "AddNewbornByMumsPHN-Request",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-add-request-bundle"
    ]
  },
  "type" : "collection",
  "timestamp" : "2023-01-23T13:46:28.0429798-08:00",
  "link" : [
    {
      "relation" : "self",
      "url" : "urn:uuid:977f1edc-04db-439e-9f84-7cda0082812a"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "urn:uuid:66fa3c28-1121-4305-bda2-4e834fcbc0f8",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "AddNewbornByMumsPHN-Request-Parameters",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-in"
          ]
        },
        "parameter" : [
          {
            "name" : "messageId",
            "valueString" : "eac486dd-ffe1-4272-b1ae-1ae0b0707b92"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:66a90476-06d2-4e62-aba7-32d0566ecf41",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "AddNewbornByMumsPHN-Request-Patient",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_AddNewbornByMumsPHN-Request-Patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient AddNewbornByMumsPHN-Request-Patient</b></p><a name=\"AddNewbornByMumsPHN-Request-Patient\"> </a><a name=\"hcAddNewbornByMumsPHN-Request-Patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Baby Boy Jaroscak  Male, DoB: 2023-01-22 ( https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-viha-north-source-patient-id#4PX0WI5WO23CZRYTQ4GZP6MUJ9R6P2N6MS8Z156 (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\">46005 Lake forest drive Mattice BC CA </td></tr></table></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-viha-north-source-patient-id",
            "value" : "4PX0WI5WO23CZRYTQ4GZP6MUJ9R6P2N6MS8Z156"
          }
        ],
        "name" : [
          {
            "use" : "usual",
            "family" : "Jaroscak",
            "given" : ["Baby Boy"]
          }
        ],
        "gender" : "male",
        "birthDate" : "2023-01-22",
        "address" : [
          {
            "type" : "physical",
            "line" : ["46005 Lake forest drive"],
            "city" : "Mattice",
            "state" : "BC",
            "country" : "CA"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:b8d7f4cb-94db-46f6-9a01-7023a292b649",
      "resource" : {
        "resourceType" : "RelatedPerson",
        "id" : "AddNewbornByMumsPHN-Request-RelatedPerson",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RelatedPerson_AddNewbornByMumsPHN-Request-RelatedPerson\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RelatedPerson AddNewbornByMumsPHN-Request-RelatedPerson</b></p><a name=\"AddNewbornByMumsPHN-Request-RelatedPerson\"> </a><a name=\"hcAddNewbornByMumsPHN-Request-RelatedPerson\"> </a><p><b>identifier</b>: <code>https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id</code>/9253484802 (use: official, period: 2023-01-23 13:46:27-0800 --&gt; (ongoing))</p><p><b>patient</b>: <a href=\"Bundle-AddNewbornByMumsPHN-Request.html#urn-uuid-66a90476-06d2-4e62-aba7-32d0566ecf41\">Baby Boy Jaroscak  Male, DoB: 2023-01-22 ( https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-viha-north-source-patient-id#4PX0WI5WO23CZRYTQ4GZP6MUJ9R6P2N6MS8Z156 (use: official, ))</a></p><p><b>relationship</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleCode NMTH}\">natural mother</span></p></div>"
        },
        "identifier" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              }
            ],
            "use" : "official",
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id",
            "value" : "9253484802",
            "period" : {
              "start" : "2023-01-23T13:46:27-08:00"
            }
          }
        ],
        "patient" : {
          "reference" : "urn:uuid:66a90476-06d2-4e62-aba7-32d0566ecf41"
        },
        "relationship" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
                "code" : "NMTH"
              }
            ]
          }
        ]
      }
    }
  ]
}

```
