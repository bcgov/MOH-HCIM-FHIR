# Revise-Request-No-SRI - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Revise-Request-No-SRI**

## Example Bundle: Revise-Request-No-SRI



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Revise-Request-No-SRI",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-revise-request-bundle"
    ]
  },
  "type" : "collection",
  "timestamp" : "2024-11-28T06:27:01.3453761-08:00",
  "link" : [
    {
      "relation" : "self",
      "url" : "urn:uuid:378954cb-6473-4399-b99c-1bd2988950ae"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "urn:uuid:feece490-6a8b-48c3-bd35-6a16008c19ef",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "Revise-Request-No-SRI-Parameters",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-in"
          ]
        },
        "parameter" : [
          {
            "name" : "messageId",
            "valueString" : "76648f54-2dd3-40f4-b6bd-5c39386061b2"
          },
          {
            "name" : "sender",
            "valueIdentifier" : {
              "system" : "http://hlth.gov.bc.ca/fhir/client/bc-org",
              "value" : "FHA"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:23d2b2f0-7724-4959-9007-302b26499633",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "Revise-Request-No-SRI-Patient",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_Revise-Request-No-SRI-Patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient Revise-Request-No-SRI-Patient</b></p><a name=\"Revise-Request-No-SRI-Patient\"> </a><a name=\"hcRevise-Request-No-SRI-Patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Proinnsias Edmon Beartlaidh Tabatabai  Female, DoB: 1996-02-18 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-msp-eligibility-id#?ngen-9? (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Alternate names (see the one above)\">Alt. Name:</td><td colspan=\"3\">Victor (Nickname)</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: 3104702526(Mobile)</li><li>ph: 3366898069(Home)</li><li>ph: 2544265519(Work)</li><li><a href=\"mailto:Constance.Besarra@cgi.com\">Constance.Besarra@cgi.com</a></li><li><a href=\"mailto:Hank.Avey@cgi.com\">Hank.Avey@cgi.com</a></li><li><a href=\"mailto:Nerissa.Friede@cgi.com\">Nerissa.Friede@cgi.com</a></li><li>7562 Railroad street Calistoga BC V5QOX7 CA </li><li>27523 Oak street Topmost BC V4IUH0 CA </li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The effective dates for the parent element.\"><a href=\"StructureDefinition-bc-business-period-extension.html\">BC Business Dates</a></td><td colspan=\"3\">2024-11-28 06:22:01-0800 --&gt; (ongoing)</td></tr></table></div>"
        },
        "extension" : [
          {
            "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
            "valuePeriod" : {
              "start" : "2024-11-28T06:22:01.0974407-08:00"
            }
          }
        ],
        "identifier" : [
          {
            "use" : "official",
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-msp-eligibility-id",
            "_value" : {
              "extension" : [
                {
                  "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                  "valueCode" : "unknown"
                }
              ]
            }
          }
        ],
        "name" : [
          {
            "use" : "usual",
            "family" : "Tabatabai",
            "given" : ["Proinnsias", "Edmon", "Beartlaidh"]
          },
          {
            "use" : "nickname",
            "given" : ["Victor"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "3104702526",
            "use" : "mobile"
          },
          {
            "system" : "phone",
            "value" : "3366898069",
            "use" : "home"
          },
          {
            "system" : "phone",
            "value" : "2544265519",
            "use" : "work"
          },
          {
            "system" : "email",
            "value" : "Constance.Besarra@cgi.com",
            "use" : "mobile"
          },
          {
            "system" : "email",
            "value" : "Hank.Avey@cgi.com",
            "use" : "home"
          },
          {
            "system" : "email",
            "value" : "Nerissa.Friede@cgi.com",
            "use" : "work"
          }
        ],
        "gender" : "female",
        "birthDate" : "1996-02-18",
        "address" : [
          {
            "type" : "physical",
            "line" : ["7562 Railroad street"],
            "city" : "Calistoga",
            "state" : "BC",
            "postalCode" : "V5QOX7",
            "country" : "CA"
          },
          {
            "type" : "postal",
            "line" : ["27523 Oak street"],
            "city" : "Topmost",
            "state" : "BC",
            "postalCode" : "V4IUH0",
            "country" : "CA"
          }
        ]
      }
    }
  ]
}

```
