# Client Registry Overview - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* **Client Registry Overview**

## Client Registry Overview

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/ImplementationGuide/fhir.ca-bc.client | *Version*:1.0.0 |
| Active as of 2025-11-21 | *Computable Name*:BCHealthClientIdentityManagement |

The Client Registry is the authoritative registry of health care client demographics information in British Columbia. The purpose of the Provincial Client Registry is to:

* assign a Personal Health Number (PHN) for all receivers of healthcare services;
* maintain client demographic information (e.g., name, address, contact) in relation to those PHNs; and
* collect and link identity information about clients who have received a healthcare service across the BC health sector.

Authorized users with a point of service application integrated with the Client Registry can:

* search for and capture patient identity information to support safe health care service delivery;
* store client demographics from the Client Registry in the point of service application;
* update client demographic information in the Client Registry; and
* create PHNs for patients.

Client Registry currently has a HL7 V3 implementation and this guide describes the HL7 FHIR implementation.

### Miscellaneous

Conformance verbs - SHALL, SHOULD, MAY - used in this guide's Capability Statement are defined in [FHIR Conformance Rules](http://hl7.org/fhir/conformance-rules.html#conflang). The informative information outside the Capability Statement is intended to be descriptive and guide implementors through the profiles and examples without any formal requirements language.

Data absent reasons are supported, see [this page](absentData.md).

### Navigation and Other Links

See British Columbia's [Health Information Exchange](https://www2.gov.bc.ca/gov/content/health/practitioner-professional-resources/software) for more for details on the Client Registry system and access to Client Registry.

For design information start [here](design.md), to view details about profiles, operations, examples, etc, view this [page](artifacts.md).

Releases are described [here](futurePlans.md).

