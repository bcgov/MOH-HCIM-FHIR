# Merge-Response - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Merge-Response**

## Example Parameters: Merge-Response

## Parameters



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Merge-Response",
  "parameter" : [
    {
      "name" : "outcome",
      "resource" : {
        "resourceType" : "OperationOutcome",
        "issue" : [
          {
            "severity" : "information",
            "code" : "business-rule",
            "details" : {
              "coding" : [
                {
                  "system" : "https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-oo-codes",
                  "code" : "BCHCIM.PM.0.0008"
                }
              ],
              "text" : "The Person Merge request has completed successfully."
            }
          }
        ]
      }
    },
    {
      "name" : "result",
      "resource" : {
        "resourceType" : "Patient",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "identifier" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              }
            ],
            "use" : "official",
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-exp-source-patient-id",
            "value" : "U6UQG3285Z5NG23110E2",
            "period" : {
              "start" : "2025-01-16T12:54:54-08:00"
            },
            "assigner" : {
              "display" : "FHA Fraser Health Expanse - FHA_EXP"
            }
          }
        ]
      }
    }
  ]
}

```
