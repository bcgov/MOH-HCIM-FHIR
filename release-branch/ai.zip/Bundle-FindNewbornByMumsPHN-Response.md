# FindNewbornByMumsPHN-Response - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FindNewbornByMumsPHN-Response**

## Example Bundle: FindNewbornByMumsPHN-Response



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FindNewbornByMumsPHN-Response",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-search-response-bundle"
    ]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:91dd7048-9bcc-405a-844b-47dc2656fd07"
  },
  "type" : "searchset",
  "timestamp" : "2023-01-23T13:58:38.9793487-08:00",
  "total" : 3,
  "link" : [
    {
      "relation" : "canonical",
      "url" : "https://ig.cgi.com/Patient/Find.fhir"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "urn:uuid:b46f78e1-cfa1-41a6-ba9c-fafe6822791a",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "FindNewbornByMumsPHN-Response-Parameters",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-out"
          ]
        },
        "parameter" : [
          {
            "name" : "messageId",
            "valueString" : "9acccdc8-b4d0-4ac7-9f10-80d0c80136e4"
          },
          {
            "name" : "sender",
            "valueIdentifier" : {
              "system" : "http://hlth.gov.bc.ca/fhir/client/bc-org",
              "value" : "FHA"
            }
          },
          {
            "name" : "identifiersOnly",
            "valueBoolean" : false
          },
          {
            "name" : "enterer",
            "valueIdentifier" : {
              "system" : "http://hlth.gov.bc.ca/fhir/client/bc-userid",
              "value" : "ig.samples@cgi.com"
            }
          },
          {
            "name" : "requestMessageId",
            "valueString" : "2a956654-9d48-422b-ab23-ea708462760b"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:c3e604ec-0917-41a8-9d90-1da8e6611234",
      "resource" : {
        "resourceType" : "OperationOutcome",
        "id" : "FindNewbornByMumsPHN-Response-Outcome",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_FindNewbornByMumsPHN-Response-Outcome\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome FindNewbornByMumsPHN-Response-Outcome</b></p><a name=\"FindNewbornByMumsPHN-Response-Outcome\"> </a><a name=\"hcFindNewbornByMumsPHN-Response-Outcome\"> </a><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Details</b></td></tr><tr><td style=\"display: none\">*</td><td>Information</td><td>Business Rule Violation</td><td><span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-oo-codes BCHCIM.FC.0.0012}\">The search completed successfully.</span></td></tr></table></div>"
        },
        "issue" : [
          {
            "severity" : "information",
            "code" : "business-rule",
            "details" : {
              "coding" : [
                {
                  "system" : "https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-oo-codes",
                  "code" : "BCHCIM.FC.0.0012"
                }
              ],
              "text" : "The search completed successfully."
            }
          }
        ]
      },
      "search" : {
        "mode" : "outcome"
      }
    },
    {
      "fullUrl" : "urn:uuid:d71c7185-8419-455d-bd39-cb184193ddbc",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "26a6dc2a-8bad-45f3-b8e2-8829f554e8a4",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_26a6dc2a-8bad-45f3-b8e2-8829f554e8a4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 26a6dc2a-8bad-45f3-b8e2-8829f554e8a4</b></p><a name=\"26a6dc2a-8bad-45f3-b8e2-8829f554e8a4\"> </a><a name=\"hc26a6dc2a-8bad-45f3-b8e2-8829f554e8a4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Baby Girl Shawley  Female, DoB: 2023-01-22 ( https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-mt-source-patient-id#TCYS809BQAQS9323KO27C74502OZF714KM29 (use: official, period: 2023-01-23 13:58:38-0800 --&gt; (ongoing)))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\"><code>https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id</code>/9999999991 (use: official, period: 2023-01-23 13:58:38-0800 --&gt; (ongoing))</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>13719 Froe street Aylesford BC CA </li><li>24989 School street Thermal BC CA </li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              }
            ],
            "use" : "official",
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id",
            "value" : "9999999991",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            },
            "assigner" : {
              "display" : "MOH Client Registry - MOH_CRS"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              }
            ],
            "use" : "official",
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-mt-source-patient-id",
            "value" : "TCYS809BQAQS9323KO27C74502OZF714KM29",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            },
            "assigner" : {
              "display" : "FHA Meditech - Fraser Valley - FHA_MT"
            }
          }
        ],
        "active" : true,
        "name" : [
          {
            "use" : "usual",
            "family" : "Shawley",
            "given" : ["Baby Girl"],
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            }
          }
        ],
        "gender" : "female",
        "_gender" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
              "valuePeriod" : {
                "start" : "2023-01-23T13:58:38-08:00"
              }
            }
          ]
        },
        "birthDate" : "2023-01-22",
        "_birthDate" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
              "valuePeriod" : {
                "start" : "2023-01-23T13:58:38-08:00"
              }
            }
          ]
        },
        "address" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension",
                "valueCode" : "unknown"
              }
            ],
            "type" : "physical",
            "line" : ["13719 Froe street"],
            "city" : "Aylesford",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension",
                "valueCode" : "unknown"
              }
            ],
            "type" : "postal",
            "line" : ["24989 School street"],
            "city" : "Thermal",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:c7c91331-ef61-4153-b01e-b8d6447b66c5",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "2e5169f0-7a01-49cc-8006-39d4c2bdc0ee",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_2e5169f0-7a01-49cc-8006-39d4c2bdc0ee\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 2e5169f0-7a01-49cc-8006-39d4c2bdc0ee</b></p><a name=\"2e5169f0-7a01-49cc-8006-39d4c2bdc0ee\"> </a><a name=\"hc2e5169f0-7a01-49cc-8006-39d4c2bdc0ee\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Baby Girl Shawley  Female, DoB: 2023-01-22 ( https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-mt-source-patient-id#PC88F0F67VI3AJMI (use: official, period: 2023-01-23 13:58:38-0800 --&gt; (ongoing)))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\"><code>https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id</code>/9999999992 (use: official, period: 2023-01-23 13:58:38-0800 --&gt; (ongoing))</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>13719 Froe street Aylesford BC CA </li><li>24989 School street Thermal BC CA </li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              }
            ],
            "use" : "official",
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id",
            "value" : "9999999992",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            },
            "assigner" : {
              "display" : "MOH Client Registry - MOH_CRS"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              }
            ],
            "use" : "official",
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-mt-source-patient-id",
            "value" : "PC88F0F67VI3AJMI",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            },
            "assigner" : {
              "display" : "FHA Meditech - Fraser Valley - FHA_MT"
            }
          }
        ],
        "active" : true,
        "name" : [
          {
            "use" : "usual",
            "family" : "Shawley",
            "given" : ["Baby Girl"],
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            }
          }
        ],
        "gender" : "female",
        "_gender" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
              "valuePeriod" : {
                "start" : "2023-01-23T13:58:38-08:00"
              }
            }
          ]
        },
        "birthDate" : "2023-01-22",
        "_birthDate" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
              "valuePeriod" : {
                "start" : "2023-01-23T13:58:38-08:00"
              }
            }
          ]
        },
        "address" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension",
                "valueCode" : "unknown"
              }
            ],
            "type" : "physical",
            "line" : ["13719 Froe street"],
            "city" : "Aylesford",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension",
                "valueCode" : "unknown"
              }
            ],
            "type" : "postal",
            "line" : ["24989 School street"],
            "city" : "Thermal",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:beda6325-3140-444e-af5b-0f6c320b98d1",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "7668592e-2316-4ea8-bbab-bb601239e71e",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_7668592e-2316-4ea8-bbab-bb601239e71e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 7668592e-2316-4ea8-bbab-bb601239e71e</b></p><a name=\"7668592e-2316-4ea8-bbab-bb601239e71e\"> </a><a name=\"hc7668592e-2316-4ea8-bbab-bb601239e71e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Dietrich Shawley  Female, DoB: 2022-12-17 ( https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-mt-source-patient-id#9ZJVK0Z8Y4QS232 (use: official, period: 2023-01-23 13:58:38-0800 --&gt; (ongoing)))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\"><code>https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id</code>/9999999999 (use: official, period: 2023-01-23 13:58:38-0800 --&gt; (ongoing))</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: 3142487326(Home)</li><li>13719 Froe street Aylesford BC CA </li><li>24989 School street Thermal BC CA </li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Patient Links\">Links:</td><td colspan=\"3\"><ul><li>Also see: <a href=\"Bundle-FindNewbornByMumsPHN-Response.html#urn-uuid-13cb4c36-102d-49c7-9f2e-f652ece39ecf\">RelatedPerson: relationship = natural mother</a></li><li>Also see: <a href=\"Bundle-FindNewbornByMumsPHN-Response.html#urn-uuid-613f5d13-9753-4c0c-89f9-f2bce0622721\">RelatedPerson: relationship = natural mother</a></li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              }
            ],
            "use" : "official",
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id",
            "value" : "9999999999",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            },
            "assigner" : {
              "display" : "MOH Client Registry - MOH_CRS"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              }
            ],
            "use" : "official",
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-mt-source-patient-id",
            "value" : "9ZJVK0Z8Y4QS232",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            },
            "assigner" : {
              "display" : "FHA Meditech - Fraser Valley - FHA_MT"
            }
          }
        ],
        "active" : true,
        "name" : [
          {
            "use" : "usual",
            "family" : "Shawley",
            "given" : ["Dietrich"],
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            }
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "3142487326",
            "use" : "home",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            }
          }
        ],
        "gender" : "female",
        "_gender" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
              "valuePeriod" : {
                "start" : "2023-01-23T13:58:38-08:00"
              }
            }
          ]
        },
        "birthDate" : "2022-12-17",
        "_birthDate" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
              "valuePeriod" : {
                "start" : "2023-01-23T13:58:38-08:00"
              }
            }
          ]
        },
        "address" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension",
                "valueCode" : "unknown"
              }
            ],
            "type" : "physical",
            "line" : ["13719 Froe street"],
            "city" : "Aylesford",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension",
                "valueCode" : "unknown"
              }
            ],
            "type" : "postal",
            "line" : ["24989 School street"],
            "city" : "Thermal",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2023-01-23T13:58:38-08:00"
            }
          }
        ],
        "link" : [
          {
            "other" : {
              "reference" : "urn:uuid:13cb4c36-102d-49c7-9f2e-f652ece39ecf"
            },
            "type" : "seealso"
          },
          {
            "other" : {
              "reference" : "urn:uuid:613f5d13-9753-4c0c-89f9-f2bce0622721"
            },
            "type" : "seealso"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:13cb4c36-102d-49c7-9f2e-f652ece39ecf",
      "resource" : {
        "resourceType" : "RelatedPerson",
        "id" : "FindNewbornByMumsPHN-Response-RelatedPerson1",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RelatedPerson_FindNewbornByMumsPHN-Response-RelatedPerson1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RelatedPerson FindNewbornByMumsPHN-Response-RelatedPerson1</b></p><a name=\"FindNewbornByMumsPHN-Response-RelatedPerson1\"> </a><a name=\"hcFindNewbornByMumsPHN-Response-RelatedPerson1\"> </a><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&amp;canonical=urn:uuid:71092811-55f9-4e1f-8754-a6828da1d51c\">urn:uuid:71092811-55f9-4e1f-8754-a6828da1d51c</a></p><p><b>relationship</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleCode NMTH}\">natural mother</span></p></div>"
        },
        "patient" : {
          "reference" : "urn:uuid:71092811-55f9-4e1f-8754-a6828da1d51c"
        },
        "relationship" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
                "code" : "NMTH"
              }
            ]
          }
        ]
      },
      "search" : {
        "mode" : "include"
      }
    },
    {
      "fullUrl" : "urn:uuid:613f5d13-9753-4c0c-89f9-f2bce0622721",
      "resource" : {
        "resourceType" : "RelatedPerson",
        "id" : "FindNewbornByMumsPHN-Response-RelatedPerson2",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RelatedPerson_FindNewbornByMumsPHN-Response-RelatedPerson2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RelatedPerson FindNewbornByMumsPHN-Response-RelatedPerson2</b></p><a name=\"FindNewbornByMumsPHN-Response-RelatedPerson2\"> </a><a name=\"hcFindNewbornByMumsPHN-Response-RelatedPerson2\"> </a><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&amp;canonical=urn:uuid:69b91ae6-e147-4dd0-abe7-8912ec301fd9\">urn:uuid:69b91ae6-e147-4dd0-abe7-8912ec301fd9</a></p><p><b>relationship</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleCode NMTH}\">natural mother</span></p></div>"
        },
        "patient" : {
          "reference" : "urn:uuid:69b91ae6-e147-4dd0-abe7-8912ec301fd9"
        },
        "relationship" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
                "code" : "NMTH"
              }
            ]
          }
        ]
      },
      "search" : {
        "mode" : "include"
      }
    }
  ]
}

```
