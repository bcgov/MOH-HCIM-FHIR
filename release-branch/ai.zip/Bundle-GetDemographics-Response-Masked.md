# GetDemographics-Response-Masked - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographics-Response-Masked**

## Example Bundle: GetDemographics-Response-Masked



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "GetDemographics-Response-Masked",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-search-response-bundle"
    ]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:be0ea88b-cb92-46a5-8ae8-5aaa943d99c0"
  },
  "type" : "searchset",
  "timestamp" : "2024-11-28T06:27:01.3305055-08:00",
  "total" : 1,
  "link" : [
    {
      "relation" : "canonical",
      "url" : "https://localhost/$GetDemographics"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "urn:uuid:a5aadea1-11ad-4428-a7d3-88a8e284c261",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "GetDemographics-Response-Masked-Parameters",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-out"
          ]
        },
        "parameter" : [
          {
            "name" : "messageId",
            "valueString" : "76648f54-2dd3-40f4-b6bd-5c39386061b2"
          },
          {
            "name" : "history",
            "valueBoolean" : false
          },
          {
            "name" : "identifiersOnly",
            "valueBoolean" : false
          }
        ]
      }
    },
    {
      "resource" : {
        "resourceType" : "OperationOutcome",
        "id" : "GetDemographics-Response-Masked-Outcome",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_GetDemographics-Response-Masked-Outcome\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome GetDemographics-Response-Masked-Outcome</b></p><a name=\"GetDemographics-Response-Masked-Outcome\"> </a><a name=\"hcGetDemographics-Response-Masked-Outcome\"> </a><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Details</b></td></tr><tr><td style=\"display: none\">*</td><td>Information</td><td>Business Rule Violation</td><td><span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-oo-codes BCHCIM.GD.0.0013}\">The get demographics query completed successfully.</span></td></tr></table></div>"
        },
        "issue" : [
          {
            "severity" : "information",
            "code" : "business-rule",
            "details" : {
              "coding" : [
                {
                  "system" : "https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-oo-codes",
                  "code" : "BCHCIM.GD.0.0013"
                }
              ],
              "text" : "The get demographics query completed successfully."
            }
          }
        ]
      },
      "search" : {
        "mode" : "outcome"
      }
    },
    {
      "resource" : {
        "resourceType" : "Patient",
        "id" : "GetDemographics-Response-Masked-Patient",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_GetDemographics-Response-Masked-Patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient GetDemographics-Response-Masked-Patient</b></p><a name=\"GetDemographics-Response-Masked-Patient\"> </a><a name=\"hcGetDemographics-Response-Masked-Patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\"> null, DoB: </p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Alternate names (see the one above)\">Alt. Name:</td><td colspan=\"3\">(Nickname)</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: -unknown-(Mobile)</li><li>ph: -unknown-(Home)</li><li>ph: -unknown-(Work)</li><li><a href=\"mailto:null\"/></li><li><a href=\"mailto:null\"/></li><li><a href=\"mailto:null\"/></li><li></li><li></li></ul></td></tr></table></div>"
        },
        "name" : [
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "masked"
              }
            ],
            "use" : "usual"
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "masked"
              }
            ],
            "use" : "nickname"
          }
        ],
        "telecom" : [
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "masked"
              }
            ],
            "system" : "phone",
            "use" : "mobile"
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "masked"
              }
            ],
            "system" : "phone",
            "use" : "home"
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "masked"
              }
            ],
            "system" : "phone",
            "use" : "work"
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "masked"
              }
            ],
            "system" : "email",
            "use" : "mobile"
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "masked"
              }
            ],
            "system" : "email",
            "use" : "home"
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "masked"
              }
            ],
            "system" : "email",
            "use" : "work"
          }
        ],
        "_gender" : {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
              "valueCode" : "masked"
            }
          ]
        },
        "_birthDate" : {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
              "valueCode" : "masked"
            }
          ]
        },
        "address" : [
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "masked"
              }
            ],
            "type" : "physical"
          },
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                "valueCode" : "masked"
              }
            ],
            "type" : "postal"
          }
        ]
      }
    }
  ]
}

```
