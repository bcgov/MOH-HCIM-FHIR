# Capability Statement - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* **Capability Statement**

## Capability Statement

### Capability Statement - Server

The Client Registry acts as a FHIR server by providing responses to Patient searches, adds and updates and insurance eligibility. The Capability Statement lists the profiles, RESTful FHIR Operations and parameters supported by the Client Registry. This information can be found [here](CapabilityStatement-bc-hcim-capability-statement-server.md)

### Capability Statement - Client

The Client Registry acts as a FHIR client by sending patient change notifications(distributions) to connected partners. The Capability Statement lists the profiles and RESTful operations supported by the Client Registry. This information can be found [here](CapabilityStatement-bc-hcim-capability-statement-client.md)

