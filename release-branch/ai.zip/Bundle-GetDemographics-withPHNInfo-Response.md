# GetDemographics-withPHNInfo-Response - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographics-withPHNInfo-Response**

## Example Bundle: GetDemographics-withPHNInfo-Response



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "GetDemographics-withPHNInfo-Response",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-search-response-bundle"
    ]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:501f39c8-a388-49a8-aaaa-cbd5d76bb5bd"
  },
  "type" : "searchset",
  "timestamp" : "2023-01-23T14:00:53.7668522-08:00",
  "total" : 1,
  "link" : [
    {
      "relation" : "canonical",
      "url" : "https://ig.cgi.com/Patient/$GetDemographics"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "urn:uuid:fb5ed5fa-e08f-4b88-948a-d81cd26d3453",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "GetDemographics-withHistory-Response-Parameters",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-out"
          ]
        },
        "parameter" : [
          {
            "name" : "messageId",
            "valueString" : "0cf19fde-0808-4ffe-b029-3aa06bc008a9"
          },
          {
            "name" : "sender",
            "valueIdentifier" : {
              "system" : "http://hlth.gov.bc.ca/fhir/client/bc-org",
              "value" : "FHA"
            }
          },
          {
            "name" : "history",
            "valueBoolean" : true
          },
          {
            "name" : "identifiersOnly",
            "valueBoolean" : false
          },
          {
            "name" : "enterer",
            "valueIdentifier" : {
              "system" : "http://hlth.gov.bc.ca/fhir/client/bc-userid",
              "value" : "ig.samples@cgi.com"
            }
          },
          {
            "name" : "requestMessageId",
            "valueString" : "62ac7557-95b4-42b0-acb1-dde7bc56c964"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:99982f86-4044-48a6-9e63-3d221f3a9876",
      "resource" : {
        "resourceType" : "OperationOutcome",
        "id" : "GetDemographics-withPHNInfo-Response-Outcome",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_GetDemographics-withPHNInfo-Response-Outcome\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome GetDemographics-withPHNInfo-Response-Outcome</b></p><a name=\"GetDemographics-withPHNInfo-Response-Outcome\"> </a><a name=\"hcGetDemographics-withPHNInfo-Response-Outcome\"> </a><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Details</b></td></tr><tr><td style=\"display: none\">*</td><td>Information</td><td>Business Rule Violation</td><td><span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-oo-codes BCHCIM.GD.0.0013}\">The get demographics query completed successfully.</span></td></tr></table></div>"
        },
        "issue" : [
          {
            "severity" : "information",
            "code" : "business-rule",
            "details" : {
              "coding" : [
                {
                  "system" : "https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-oo-codes",
                  "code" : "BCHCIM.GD.0.0013"
                }
              ],
              "text" : "The get demographics query completed successfully."
            }
          }
        ]
      },
      "search" : {
        "mode" : "outcome"
      }
    },
    {
      "fullUrl" : "urn:uuid:99982f86-4044-48a6-9e63-3d221f3a5f0d",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "87d81314-eba2-4071-af5a-f2b98bf4c13a",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_87d81314-eba2-4071-af5a-f2b98bf4c13a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 87d81314-eba2-4071-af5a-f2b98bf4c13a</b></p><a name=\"87d81314-eba2-4071-af5a-f2b98bf4c13a\"> </a><a name=\"hc87d81314-eba2-4071-af5a-f2b98bf4c13a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Alithea Joacheim Aine Parthemore  Female, DoB: 1946-11-28 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-ab-patient-healthcare-id#SL4I3I1512EF5KFN6S09E5 (use: official, period: 2023-01-23 14:00:53-0800 --&gt; (ongoing)))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td>true</td><td style=\"background-color: #f3f5da\" title=\"Known status of Patient\">Deceased:</td><td colspan=\"3\">1950-07-16</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li><code>https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id</code>/9999999999 (use: official, period: 2023-01-23 14:00:53-0800 --&gt; (ongoing))</li><li><code>https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-fv-source-patient-id</code>/2701XI3IW2R95W87WH3H16082KJ2LEVENM0LNTW (use: official, period: 2023-01-23 14:00:53-0800 --&gt; (ongoing))</li><li><code>https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-fv-source-patient-id</code>/3B022OESRB7W41F3511QJ9PDCE244509HWHH5J (use: official, period: 2018-01-23 14:00:53-0800 --&gt; 2023-01-23 14:00:53-0800)</li><li><code>https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-arh-source-patient-id</code>/8FV66J82GPKBH83 (use: secondary, period: 2023-01-23 14:00:53-0800 --&gt; (ongoing))</li><li><code>https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-bh-source-patient-id</code>/UO9W191ASP6JN937P3H476IPHC0K83V4Q65 (use: secondary, period: 2018-01-23 14:00:53-0800 --&gt; 2023-01-23 14:00:53-0800)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: 6237064105(Mobile)</li><li>ph: 6304712096(Mobile)</li><li>ph: 7121011390(Home)</li><li>ph: 4163176376(Home)</li><li>ph: 9845613474(Work)</li><li>ph: 2054428883(Work)</li><li><a href=\"mailto:Berne.Aron@cgi.com\">Berne.Aron@cgi.com</a></li><li><a href=\"mailto:Octavius.Megown@cgi.com\">Octavius.Megown@cgi.com</a></li><li><a href=\"mailto:Claude.Abuel@cgi.com\">Claude.Abuel@cgi.com</a></li><li><a href=\"mailto:Madailein.Ivins@cgi.com\">Madailein.Ivins@cgi.com</a></li><li><a href=\"mailto:Akanni.Ehrler@cgi.com\">Akanni.Ehrler@cgi.com</a></li><li><a href=\"mailto:Tereza.Bis@cgi.com\">Tereza.Bis@cgi.com</a></li><li>1431 Riverwood drive Lake village BC CA </li><li>7597 Mahlon street Maple plain BC CA </li><li>1699 Brand road Hills BC CA </li><li>33031 Arrowood drive Mayfield heights BC CA </li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              },
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "MEDP_EMR"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Monica.Simmonds@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "official",
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id",
            "value" : "9999999999",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            },
            "assigner" : {
              "display" : "MOH Client Registry - MOH_CRS"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              },
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VIHA_JOEADT"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Dorthe.Rought@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "official",
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-fv-source-patient-id",
            "value" : "2701XI3IW2R95W87WH3H16082KJ2LEVENM0LNTW",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            },
            "assigner" : {
              "display" : "FHA Meditech - Fraser Valley - FHA_FV"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "merged"
              },
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VCHA_VGH"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Uberto.Sow@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "official",
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-fv-source-patient-id",
            "value" : "3B022OESRB7W41F3511QJ9PDCE244509HWHH5J",
            "period" : {
              "start" : "2018-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            },
            "assigner" : {
              "display" : "FHA Meditech - Fraser Valley - FHA_FV"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              },
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "PHSA_A"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Kennocha.Debreto@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "secondary",
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-arh-source-patient-id",
            "value" : "8FV66J82GPKBH83",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            },
            "assigner" : {
              "display" : "Abbotsford Regional Hospital"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "merged"
              },
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "FHA_SF"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Ivonne.Rustad@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "secondary",
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-bh-source-patient-id",
            "value" : "UO9W191ASP6JN937P3H476IPHC0K83V4Q65",
            "period" : {
              "start" : "2018-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            },
            "assigner" : {
              "display" : "Burnaby Hospital"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension",
                "valueCode" : "active"
              },
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VCHA_VGH"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Kate.Kamin@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "official",
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-ab-patient-healthcare-id",
            "value" : "SL4I3I1512EF5KFN6S09E5",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          }
        ],
        "active" : true,
        "name" : [
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VCHA_VGH"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Leo.Perler@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "usual",
            "family" : "Parthemore",
            "given" : ["Alithea", "Joacheim", "Aine"],
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "HIBC_MSP"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Amandine.Norem@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "usual",
            "family" : "Kalscheuer",
            "given" : ["Christina", "Matei", "Marlin"],
            "period" : {
              "start" : "2020-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "NHA_CER"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Franchot.Depaolo@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "official",
            "given" : ["Abaigh", "Evangelia", "Wahchinksapa"],
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VIHA_JOELAB"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Akono.Viscia@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "official",
            "given" : ["Wilhelmus", "Galatea", "Olabisi"],
            "period" : {
              "start" : "2017-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "NHA_CER"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Florentin.Klostermann@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "nickname",
            "given" : ["Mia"],
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VCHA_RICH"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Flora.Demeester@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "use" : "nickname",
            "given" : ["Jutta"],
            "period" : {
              "start" : "2020-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          }
        ],
        "telecom" : [
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VIHA_SOUTH"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Margaret.Wilkins@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "phone",
            "value" : "6237064105",
            "use" : "mobile",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VCHA_PR"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Alissandre.Pfannenstiel@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "phone",
            "value" : "6304712096",
            "use" : "mobile",
            "period" : {
              "start" : "2021-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VIHA_SOUTH"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Annunziata.Dronet@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "phone",
            "value" : "7121011390",
            "use" : "home",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VIHA_CENT"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Hesutu.Rohs@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "phone",
            "value" : "4163176376",
            "use" : "home",
            "period" : {
              "start" : "2017-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "PHNBOUND_RX"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Ngozi.Kinlin@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "phone",
            "value" : "9845613474",
            "use" : "work",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "HIBC_MSP"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Hjalmar.Mickonis@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "phone",
            "value" : "2054428883",
            "use" : "work",
            "period" : {
              "start" : "2017-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VIHA_NORTH"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Koren.Healy@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "email",
            "value" : "Berne.Aron@cgi.com",
            "use" : "mobile",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "FHA_PARIS"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Marcelle.Melton@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "email",
            "value" : "Octavius.Megown@cgi.com",
            "use" : "mobile",
            "period" : {
              "start" : "2020-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VIHA_JOEADT"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Leslie.Villela@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "email",
            "value" : "Claude.Abuel@cgi.com",
            "use" : "home",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VIHA_JOELAB"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Rhoda.Hergenroeder@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "email",
            "value" : "Madailein.Ivins@cgi.com",
            "use" : "home",
            "period" : {
              "start" : "2019-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VIHA_NORTH"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Mana.Novielli@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "email",
            "value" : "Akanni.Ehrler@cgi.com",
            "use" : "work",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "PHSA_P"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Mary.Kirkpatrick@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "system" : "email",
            "value" : "Tereza.Bis@cgi.com",
            "use" : "work",
            "period" : {
              "start" : "2017-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          }
        ],
        "gender" : "female",
        "_gender" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
              "valuePeriod" : {
                "start" : "2023-01-23T14:00:53-08:00"
              }
            },
            {
              "extension" : [
                {
                  "url" : "sourceID",
                  "valueString" : "FHA_SF"
                },
                {
                  "url" : "userID",
                  "valueString" : "Irving.Desmarias@samples.com"
                }
              ],
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
            },
            {
              "extension" : [
                {
                  "url" : "gender",
                  "valueCode" : "female"
                },
                {
                  "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
                  "valuePeriod" : {
                    "start" : "2019-01-23T14:00:53-08:00",
                    "end" : "2023-01-23T14:00:53-08:00"
                  }
                },
                {
                  "extension" : [
                    {
                      "url" : "sourceID",
                      "valueString" : "VIHA_NORTH"
                    },
                    {
                      "url" : "userID",
                      "valueString" : "Dougal.Stelle@samples.com"
                    }
                  ],
                  "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
                }
              ],
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-gender-history-extension"
            }
          ]
        },
        "birthDate" : "1946-11-28",
        "_birthDate" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
              "valuePeriod" : {
                "start" : "2023-01-23T14:00:53-08:00"
              }
            },
            {
              "extension" : [
                {
                  "url" : "sourceID",
                  "valueString" : "FHA_FV"
                },
                {
                  "url" : "userID",
                  "valueString" : "Maitena.Moulin@samples.com"
                }
              ],
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
            },
            {
              "extension" : [
                {
                  "url" : "birthDate",
                  "valueDate" : "1995-07-05"
                },
                {
                  "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
                  "valuePeriod" : {
                    "start" : "2017-01-23T14:00:53-08:00",
                    "end" : "2023-01-23T14:00:53-08:00"
                  }
                },
                {
                  "extension" : [
                    {
                      "url" : "sourceID",
                      "valueString" : "FHA_PRO"
                    },
                    {
                      "url" : "userID",
                      "valueString" : "Ulrich.Degenhart@samples.com"
                    }
                  ],
                  "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
                }
              ],
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-birthdate-history-extension"
            }
          ]
        },
        "deceasedDateTime" : "1950-07-16",
        "_deceasedDateTime" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
              "valuePeriod" : {
                "start" : "2023-01-23T14:00:53-08:00"
              }
            },
            {
              "extension" : [
                {
                  "url" : "sourceID",
                  "valueString" : "VCHA_PR"
                },
                {
                  "url" : "userID",
                  "valueString" : "Ottavio.Glovier@samples.com"
                }
              ],
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
            },
            {
              "extension" : [
                {
                  "url" : "deathVerifiedFlag",
                  "valueBoolean" : false
                },
                {
                  "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
                  "valuePeriod" : {
                    "start" : "2023-01-23T14:00:53-08:00"
                  }
                },
                {
                  "extension" : [
                    {
                      "url" : "sourceID",
                      "valueString" : "PHNBOUND_RX"
                    },
                    {
                      "url" : "userID",
                      "valueString" : "Jose.Baranovic@samples.com"
                    }
                  ],
                  "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
                },
                {
                  "extension" : [
                    {
                      "url" : "deathVerifiedFlag",
                      "valueBoolean" : false
                    },
                    {
                      "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
                      "valuePeriod" : {
                        "start" : "2021-01-23T14:00:53-08:00",
                        "end" : "2023-01-23T14:00:53-08:00"
                      }
                    },
                    {
                      "extension" : [
                        {
                          "url" : "sourceID",
                          "valueString" : "VCHA_VGH"
                        },
                        {
                          "url" : "userID",
                          "valueString" : "Aline.Otter@samples.com"
                        }
                      ],
                      "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
                    }
                  ],
                  "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-verified-flag-history-extension"
                }
              ],
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-verified-flag-extension"
            },
            {
              "extension" : [
                {
                  "url" : "deathDate",
                  "valueDateTime" : "2000-02-04"
                },
                {
                  "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
                  "valuePeriod" : {
                    "start" : "2020-01-23T14:00:53-08:00",
                    "end" : "2023-01-23T14:00:53-08:00"
                  }
                },
                {
                  "extension" : [
                    {
                      "url" : "sourceID",
                      "valueString" : "IHA_IHA"
                    },
                    {
                      "url" : "userID",
                      "valueString" : "Deina.Deandrade@samples.com"
                    }
                  ],
                  "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
                }
              ],
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-date-history-extension"
            }
          ]
        },
        "address" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension",
                "valueCode" : "unknown"
              },
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "PHARM_RX"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Yuli.Raulston@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "type" : "physical",
            "line" : ["1431 Riverwood drive"],
            "city" : "Lake village",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension",
                "valueCode" : "unknown"
              },
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VCHA_PHC"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Clarence.Beloate@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "type" : "physical",
            "line" : ["7597 Mahlon street"],
            "city" : "Maple plain",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2017-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension",
                "valueCode" : "unknown"
              },
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VIHA_JOELAB"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Jeannot.Buchinski@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "type" : "postal",
            "line" : ["1699 Brand road"],
            "city" : "Hills",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2023-01-23T14:00:53-08:00"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension",
                "valueCode" : "unknown"
              },
              {
                "extension" : [
                  {
                    "url" : "sourceID",
                    "valueString" : "VCHA_VGH"
                  },
                  {
                    "url" : "userID",
                    "valueString" : "Cormac.Moor@samples.com"
                  }
                ],
                "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension"
              }
            ],
            "type" : "postal",
            "line" : ["33031 Arrowood drive"],
            "city" : "Mayfield heights",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2020-01-23T14:00:53-08:00",
              "end" : "2023-01-23T14:00:53-08:00"
            }
          }
        ]
      }
    }
  ]
}

```
