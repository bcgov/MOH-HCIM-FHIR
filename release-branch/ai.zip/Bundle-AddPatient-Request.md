# AddPatient-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AddPatient-Request**

## Example Bundle: AddPatient-Request

This is an example of the AddPatient Operation used by connected partners to 'force create' a PHN.

The **first** resource is a Parameters (MetadataParametersIn) with message ID and date and time.

The **second** resource is the Patient (ClientRegistryPatient) with the patient's information.



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "AddPatient-Request",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-add-request-bundle"
    ]
  },
  "type" : "collection",
  "timestamp" : "2023-01-23T13:46:27.8145754-08:00",
  "link" : [
    {
      "relation" : "self",
      "url" : "urn:uuid:492f0b38-e195-4249-b8d7-8000218842e9"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "urn:uuid:0185235c-f8ea-4107-8979-591ddc2df30b",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "b16bb592-6bb0-4541-8cba-4a6e741c8da7",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-in"
          ]
        },
        "parameter" : [
          {
            "name" : "messageId",
            "valueString" : "b02fc643-e179-4c5f-8ac3-a8d955f9ce87"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:951b9e8e-5c78-44d5-91b1-ad6fb748de4b",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "AddPatient-Request-Patient",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_AddPatient-Request-Patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient AddPatient-Request-Patient</b></p><a name=\"AddPatient-Request-Patient\"> </a><a name=\"hcAddPatient-Request-Patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Legarra Antonin Cecily Gillette  Female, DoB: 1971-01-09 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id#9253484802 (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Known status of Patient\">Deceased:</td><td colspan=\"3\">1974-05-08</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li><code>https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-msp-eligibility-id</code>/9455882493 (use: official, )</li><li><code>https://fhir.infoway-inforoute.ca/NamingSystem/ca-veterans-affairs-health-id</code>/3EP14D12Y8Q618LPKH04QW28 (use: official, )</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: 4018764201(Mobile)</li><li>ph: 9183556793(Home)</li><li>ph: 5185828695(Work)</li><li><a href=\"mailto:Kolab.Mancher@cgi.com\">Kolab.Mancher@cgi.com</a></li><li><a href=\"mailto:Gabriele.Minas@cgi.com\">Gabriele.Minas@cgi.com</a></li><li><a href=\"mailto:Rolande.Jerald@cgi.com\">Rolande.Jerald@cgi.com</a></li><li>28813 Eden drive Mattice BC CA </li><li>38708 Heritage road Epping BC CA </li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-msp-eligibility-id",
            "value" : "9455882493"
          },
          {
            "use" : "official",
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-veterans-affairs-health-id",
            "value" : "3EP14D12Y8Q618LPKH04QW28"
          },
          {
            "use" : "official",
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id",
            "value" : "9253484802"
          }
        ],
        "name" : [
          {
            "use" : "usual",
            "family" : "Gillette",
            "given" : ["Legarra", "Antonin", "Cecily"]
          },
          {
            "use" : "official",
            "family" : "Brouk",
            "given" : ["Meaveen", "Deman", "Marine"]
          },
          {
            "use" : "nickname",
            "given" : ["Jadvyga"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "4018764201",
            "use" : "mobile"
          },
          {
            "system" : "phone",
            "value" : "9183556793",
            "use" : "home"
          },
          {
            "system" : "phone",
            "value" : "5185828695",
            "use" : "work"
          },
          {
            "system" : "email",
            "value" : "Kolab.Mancher@cgi.com",
            "use" : "mobile"
          },
          {
            "system" : "email",
            "value" : "Gabriele.Minas@cgi.com",
            "use" : "home"
          },
          {
            "system" : "email",
            "value" : "Rolande.Jerald@cgi.com",
            "use" : "work"
          }
        ],
        "gender" : "female",
        "birthDate" : "1971-01-09",
        "deceasedDateTime" : "1974-05-08",
        "_deceasedDateTime" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "deathVerifiedFlag",
                  "valueBoolean" : true
                }
              ],
              "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-verified-flag-extension"
            }
          ]
        },
        "address" : [
          {
            "type" : "physical",
            "line" : ["28813 Eden drive"],
            "city" : "Mattice",
            "state" : "BC",
            "country" : "CA"
          },
          {
            "type" : "postal",
            "line" : ["38708 Heritage road"],
            "city" : "Epping",
            "state" : "BC",
            "country" : "CA"
          }
        ]
      }
    }
  ]
}

```
