# FindCandidates-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FindCandidates-Request**

## Example Bundle: FindCandidates-Request



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FindCandidates-Request",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-find-candidates-request-bundle"
    ]
  },
  "type" : "collection",
  "timestamp" : "2023-01-23T13:58:38.7538206-08:00",
  "link" : [
    {
      "relation" : "self",
      "url" : "urn:uuid:92cbad6f-b07c-4288-88fc-884a8d4d50ec"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "urn:uuid:c3e604ec-0917-41a8-9d90-1da8e66168d7",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "FindCandidates-Request-Parameters",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-in"
          ]
        },
        "parameter" : [
          {
            "name" : "messageId",
            "valueString" : "f4a5d2f7-cbea-4f80-9804-b13b9be9f2b9"
          },
          {
            "name" : "identifiersOnly",
            "valueBoolean" : false
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:f8ea5781-7772-4701-aabd-e86595f1487d",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "FindCandidates-Request-Patient",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_FindCandidates-Request-Patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient FindCandidates-Request-Patient</b></p><a name=\"FindCandidates-Request-Patient\"> </a><a name=\"hcFindCandidates-Request-Patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Apolo Frieson  Male, DoB: 1931-02-26</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\">16063 Star trek drive Evans-thomas BC CA </td></tr></table></div>"
        },
        "name" : [
          {
            "use" : "usual",
            "family" : "Frieson",
            "given" : ["Apolo"]
          }
        ],
        "gender" : "male",
        "birthDate" : "1931-02-26",
        "address" : [
          {
            "type" : "physical",
            "line" : ["16063 Star trek drive"],
            "city" : "Evans-thomas",
            "state" : "BC",
            "country" : "CA"
          }
        ]
      }
    }
  ]
}

```
