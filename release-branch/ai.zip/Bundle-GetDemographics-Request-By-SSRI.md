# GetDemographics-Request-By-SSRI - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographics-Request-By-SSRI**

## Example Bundle: GetDemographics-Request-By-SSRI



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "GetDemographics-Request-By-SSRI",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-get-demographics-request-bundle"
    ]
  },
  "type" : "collection",
  "timestamp" : "2024-11-28T06:27:01.2143422-08:00",
  "link" : [
    {
      "relation" : "self",
      "url" : "urn:uuid:86c5ee37-6bf1-4cb2-a6b3-400dfc876507"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "urn:uuid:f38e3ec9-9b39-4d2a-b8e5-0471ae234dda",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "GetDemographics-Request-By-SSRI-Parameters",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-in"
          ]
        },
        "parameter" : [
          {
            "name" : "messageId",
            "valueString" : "76648f54-2dd3-40f4-b6bd-5c39386061b2"
          },
          {
            "name" : "history",
            "valueBoolean" : false
          },
          {
            "name" : "identifiersOnly",
            "valueBoolean" : false
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:8ef35b62-3ed8-4caa-8bed-c0cff5b72738",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "GetDemographics-Request-By-SSRI-Patient",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_GetDemographics-Request-By-SSRI-Patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient GetDemographics-Request-By-SSRI-Patient</b></p><a name=\"GetDemographics-Request-By-SSRI-Patient\"> </a><a name=\"hcGetDemographics-Request-By-SSRI-Patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-patient.html\">ClientRegistryPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Anonymous Patient (no stated gender), DoB Unknown ( https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-exp-source-patient-id#MB220FXR155686125TUN (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"The effective dates for the parent element.\"><a href=\"StructureDefinition-bc-business-period-extension.html\">BC Business Dates</a></td><td colspan=\"3\">2024-11-28 06:22:01-0800 --&gt; (ongoing)</td></tr></table></div>"
        },
        "extension" : [
          {
            "url" : "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension",
            "valuePeriod" : {
              "start" : "2024-11-28T06:22:01.0974407-08:00"
            }
          }
        ],
        "identifier" : [
          {
            "use" : "official",
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-exp-source-patient-id",
            "value" : "MB220FXR155686125TUN"
          }
        ]
      }
    }
  ]
}

```
