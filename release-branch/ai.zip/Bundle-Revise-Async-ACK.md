# Revise-Async-ACK - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Revise-Async-ACK**

## Example Bundle: Revise-Async-ACK

Profile: [AsyncAckBundle](StructureDefinition-bc-async-ack-response-bundle.md)

Bundle Revise-Async-ACK of type collection

-------

Entry 1 - fullUrl = urn:uuid:e12213c8-9351-4a9b-94cb-54d3710be5b4

Resource Parameters:

> 

Profile: [MetadataParametersAsync](StructureDefinition-bc-metadata-parameter-async-response.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:e12213c8-9351-4a9b-94cb-54d3710b9876

Resource OperationOutcome:

> All OK



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Revise-Async-ACK",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-async-ack-response-bundle"
    ]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:157abc8c-036b-4fb6-960a-ba66e931189d"
  },
  "type" : "collection",
  "timestamp" : "2023-01-23T14:02:15.999572-08:00",
  "link" : [
    {
      "relation" : "canonical",
      "url" : "Patient\\Revise"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "urn:uuid:e12213c8-9351-4a9b-94cb-54d3710be5b4",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "6426876c-8118-4020-8364-7021d0a1ec23",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameter-async-response"
          ]
        },
        "parameter" : [
          {
            "name" : "messageId",
            "valueString" : "f95c3be0-b6ed-4aec-b969-7bc7da904315"
          },
          {
            "name" : "sender",
            "valueIdentifier" : {
              "system" : "http://hlth.gov.bc.ca/fhir/client/bc-org",
              "value" : "VPP"
            }
          },
          {
            "name" : "enterer",
            "valueIdentifier" : {
              "system" : "http://hlth.gov.bc.ca/fhir/client/bc-userid",
              "value" : "ig.samples@cgi.com"
            }
          },
          {
            "name" : "requestMessageId",
            "valueString" : "823d7eb6-24d5-452f-b2d0-f86f2f6130e7"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:e12213c8-9351-4a9b-94cb-54d3710b9876",
      "resource" : {
        "resourceType" : "OperationOutcome",
        "id" : "Revise-Async-ACK-Outcome",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_Revise-Async-ACK-Outcome\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome Revise-Async-ACK-Outcome</b></p><a name=\"Revise-Async-ACK-Outcome\"> </a><a name=\"hcRevise-Async-ACK-Outcome\"> </a><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Details</b></td></tr><tr><td style=\"display: none\">*</td><td>Information</td><td>Business Rule Violation</td><td><span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-oo-codes BCHCIM.RP.0.0007}\">The Revise Person request has been accepted for processing.</span></td></tr></table></div>"
        },
        "issue" : [
          {
            "severity" : "information",
            "code" : "business-rule",
            "details" : {
              "coding" : [
                {
                  "system" : "https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-oo-codes",
                  "code" : "BCHCIM.RP.0.0007"
                }
              ],
              "text" : "The Revise Person request has been accepted for processing."
            }
          }
        ]
      }
    }
  ]
}

```
