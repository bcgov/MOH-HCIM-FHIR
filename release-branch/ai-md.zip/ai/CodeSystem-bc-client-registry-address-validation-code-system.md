# BC Client Registry Address Validation Status Code - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Client Registry Address Validation Status Code**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-bc-client-registry-address-validation-code-system.xml.md) 
*  [JSON](CodeSystem-bc-client-registry-address-validation-code-system.json.md) 
*  [TTL](CodeSystem-bc-client-registry-address-validation-code-system.ttl.md) 

## CodeSystem: BC Client Registry Address Validation Status Code 

| | |
| :--- | :--- |
| *Official URL*:https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-client-registry-address-validation-code-system | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:AddressValidationCS |

 
Codes used to define the address validation status. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [AddressValidationVS](ValueSet-bc-address-validation-value-set.md)

This case-sensitive code system `https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-client-registry-address-validation-code-system` defines the following codes:

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

