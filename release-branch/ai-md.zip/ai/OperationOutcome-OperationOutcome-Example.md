# OperationOutcome-Example - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **OperationOutcome-Example**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](OperationOutcome-OperationOutcome-Example.xml.md) 
*  [JSON](OperationOutcome-OperationOutcome-Example.json.md) 
*  [TTL](OperationOutcome-OperationOutcome-Example.ttl.md) 

## Example OperationOutcome: OperationOutcome-Example

> **issue****severity**: Warning**code**: Business Rule Violation**details**:Warning: The Revise Patient name has been modified to filter out invalid characters.

> **issue****severity**: Error**code**: Business Rule Violation**details**:The HL7 message is invalid. Please correct the HL7 message, and resubmit it. (System.Exception: Results from Schematron validation: ...

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

