# BC Death Verified Flag - TTL Representation - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Death Verified Flag**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-death-verified-flag-extension.md) 
*  [Detailed Descriptions](StructureDefinition-bc-death-verified-flag-extension-definitions.md) 
*  [Mappings](StructureDefinition-bc-death-verified-flag-extension-mappings.md) 
*  [XML](StructureDefinition-bc-death-verified-flag-extension.profile.xml.md) 
*  [JSON](StructureDefinition-bc-death-verified-flag-extension.profile.json.md) 
*  [TTL](#) 

## Extension: DeathVerifiedFlagExtension - TTL Profile

| |
| :--- |
| Active as of 2025-10-07 |

TTL representation of the bc-death-verified-flag-extension extension.

[Raw ttl](StructureDefinition-bc-death-verified-flag-extension.ttl) | [Download](StructureDefinition-bc-death-verified-flag-extension.ttl)

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

