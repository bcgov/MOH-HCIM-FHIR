# PatientByExample - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PatientByExample**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-patient-by-example-definitions.md) 
*  [Mappings](StructureDefinition-bc-patient-by-example-mappings.md) 
*  [XML](StructureDefinition-bc-patient-by-example.profile.xml.md) 
*  [JSON](StructureDefinition-bc-patient-by-example.profile.json.md) 
*  [TTL](StructureDefinition-bc-patient-by-example.profile.ttl.md) 

## Resource Profile: PatientByExample 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient-by-example | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:PatientByExample |

 
Will get removed. General constraints on the Patient resource for use in the BC Client Registry project for queries. PatientByExample is a resource of the Client Registry FHIR implementation use only by Get Demographics and Find Candidates 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-patient-by-example)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

**Summary**

Must-Support: 5 elements
 Prohibited: 12 elements

**Structures**

This structure refers to these other structures:

* [Identifier DataType Profile (CA Baseline)(http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Patient.deceased[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

**Summary**

Must-Support: 5 elements
 Prohibited: 12 elements

**Structures**

This structure refers to these other structures:

* [Identifier DataType Profile (CA Baseline)(http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Patient.deceased[x]

 

Other representations of profile: [CSV](StructureDefinition-bc-patient-by-example.csv), [Excel](StructureDefinition-bc-patient-by-example.xlsx), [Schematron](StructureDefinition-bc-patient-by-example.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

