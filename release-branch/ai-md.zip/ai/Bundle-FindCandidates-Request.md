# FindCandidates-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FindCandidates-Request**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-FindCandidates-Request.xml.md) 
*  [JSON](Bundle-FindCandidates-Request.json.md) 
*  [TTL](Bundle-FindCandidates-Request.ttl.md) 

## Example Bundle: FindCandidates-Request

Profile: [FindCandidatesRequestBundle](StructureDefinition-bc-find-candidates-request-bundle.md)

Bundle FindCandidates-Request of type collection

-------

Entry 1 - fullUrl = urn:uuid:c3e604ec-0917-41a8-9d90-1da8e66168d7

Resource Parameters:

> 

Profile: [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:f8ea5781-7772-4701-aabd-e86595f1487d

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Apolo Frieson Male, DoB: 1931-02-26
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

