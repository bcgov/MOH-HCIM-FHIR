# GetDemographics-withPHNInfo-Response - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographics-withPHNInfo-Response**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-GetDemographics-withPHNInfo-Response.xml.md) 
*  [JSON](Bundle-GetDemographics-withPHNInfo-Response.json.md) 
*  [TTL](Bundle-GetDemographics-withPHNInfo-Response.ttl.md) 

## Example Bundle: GetDemographics-withPHNInfo-Response

Profile: [SearchResponseBundle](StructureDefinition-bc-search-response-bundle.md)

Bundle GetDemographics-withPHNInfo-Response of type searchset

-------

Entry 1 - fullUrl = urn:uuid:fb5ed5fa-e08f-4b88-948a-d81cd26d3453

Resource Parameters:

> 

Profile: [MetadataParametersOut](StructureDefinition-bc-metadata-parameters-out.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:99982f86-4044-48a6-9e63-3d221f3a9876

Search:Mode = outcome

Resource OperationOutcome:

> All OK

-------

Entry 3 - fullUrl = urn:uuid:99982f86-4044-48a6-9e63-3d221f3a5f0d

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Alithea Joacheim Aine Parthemore Female, DoB: 1946-11-28 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id#9999999999 (use: official, period: 2023-01-23 14:00:53-0800 --> (ongoing)))
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

