# AddResponseBundle - TTL Representation - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AddResponseBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-add-response-bundle.md) 
*  [Detailed Descriptions](StructureDefinition-bc-add-response-bundle-definitions.md) 
*  [Mappings](StructureDefinition-bc-add-response-bundle-mappings.md) 
*  [Examples](StructureDefinition-bc-add-response-bundle-examples.md) 
*  [XML](StructureDefinition-bc-add-response-bundle.profile.xml.md) 
*  [JSON](StructureDefinition-bc-add-response-bundle.profile.json.md) 
*  [TTL](#) 

## Resource Profile: AddResponseBundle - TTL Profile

| |
| :--- |
| Active as of 2025-10-07 |

TTL representation of the bc-add-response-bundle resource profile.

[Raw ttl](StructureDefinition-bc-add-response-bundle.ttl) | [Download](StructureDefinition-bc-add-response-bundle.ttl)

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

