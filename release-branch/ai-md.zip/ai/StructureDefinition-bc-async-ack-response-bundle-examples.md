# AsyncAckBundle - Examples - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AsyncAckBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-async-ack-response-bundle.md) 
*  [Detailed Descriptions](StructureDefinition-bc-async-ack-response-bundle-definitions.md) 
*  [Mappings](StructureDefinition-bc-async-ack-response-bundle-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-bc-async-ack-response-bundle.profile.xml.md) 
*  [JSON](StructureDefinition-bc-async-ack-response-bundle.profile.json.md) 
*  [TTL](StructureDefinition-bc-async-ack-response-bundle.profile.ttl.md) 

## Resource Profile: AsyncAckBundle - Examples

| |
| :--- |
| Draft as of 2025-10-07 |

Examples for the bc-async-ack-response-bundle Profile.

| |
| :--- |
| [Revise-Async-ACK](Bundle-Revise-Async-ACK.md) |

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

