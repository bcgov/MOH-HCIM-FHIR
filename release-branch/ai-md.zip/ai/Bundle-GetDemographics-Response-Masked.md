# GetDemographics-Response-Masked - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographics-Response-Masked**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-GetDemographics-Response-Masked.xml.md) 
*  [JSON](Bundle-GetDemographics-Response-Masked.json.md) 
*  [TTL](Bundle-GetDemographics-Response-Masked.ttl.md) 

## Example Bundle: GetDemographics-Response-Masked

Profile: [SearchResponseBundle](StructureDefinition-bc-search-response-bundle.md)

Bundle GetDemographics-Response-Masked of type searchset

-------

Entry 1 - fullUrl = urn:uuid:a5aadea1-11ad-4428-a7d3-88a8e284c261

Resource Parameters:

> 

Profile: [MetadataParametersOut](StructureDefinition-bc-metadata-parameters-out.md)

## Parameters


-------

Entry 2

Search:Mode = outcome

Resource OperationOutcome:

> All OK

-------

Entry 3

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

null, DoB:
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

