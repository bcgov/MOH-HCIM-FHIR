# GetDemographics - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographics**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](OperationDefinition-bc-patient-get-demographics.xml.md) 
*  [JSON](OperationDefinition-bc-patient-get-demographics.json.md) 
*  [TTL](OperationDefinition-bc-patient-get-demographics.ttl.md) 

## OperationDefinition: GetDemographics 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/OperationDefinition/bc-patient-get-demographics | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:GetDemographics |

 
This operation is used to query for a patient. The response can contain 0 or 1 Patient. 

The Get Demographics query is a FHIR Operation.

The request is a Bundle with Resources for search parameters and a Patient, i.e. [ClientRegistryClient](StructureDefinition-bc-patient.md), to match against. The Patient resource must have an identifier for this search to succeed.
 Please refer also to the [Identifiers](identifiers.md) page to find more details regarding how to use Identifier in your query.

URL: [base]/Patient?_query=GetDemographics&...

Input parameters Profile:[GetDemographicsRequestBundle](StructureDefinition-bc-get-demographics-request-bundle.md)

Output parameters Profile:[SearchResponseBundle](StructureDefinition-bc-search-response-bundle.md)

### Parameters

* **Use**: IN
  * **Name**: GetDemographicsRequestBundle
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Bundle](http://hl7.org/fhir/R4/bundle.html)
  * **Binding**: 
  * **Documentation**: GetDemographics request Bundle.
* **Use**: OUT
  * **Name**: SearchResponseBundle
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Bundle](http://hl7.org/fhir/R4/bundle.html)
  * **Binding**: 
  * **Documentation**: GetDemograponics response Bundle.

### Notes:

The response may not include any Patients if none matched the criteria. If there are patients returned, the Bundle.entry.search.score (i.e. entry for the Patient resource) will contain the Client Registry score.

In the context of the Get Demographics request message, the Patient resource must not have both a resource id (Patient.id) and a identifier(Patient.identifier) in the same request. If they are both supplied the message will be rejected.

#### In Bundle Entries

| | | |
| :--- | :--- | :--- |
| 1..1 | MetadataParametersIn | See[profile](StructureDefinition-bc-metadata-parameters-in.md). |
| 0..1 | ClientRegistryPatient | See[profile](StructureDefinition-bc-patient.md). |

#### Out Bundle Entries

| | | |
| :--- | :--- | :--- |
| 1..1 | MetadataParametersOut | See[profile](StructureDefinition-bc-metadata-parameters-out.md). |
| 1,,1 | OperationOutcome | An OperationOutcome resource that has warnings and errors regarding the operation requested. |
| 0..1 | ClientRegistryPatient | See[profile](StructureDefinition-bc-patient.md). |

#### Metadata In Parameters

Besides the two mandatory name-value pairs, see [here](StructureDefinition-bc-metadata-parameters-in.md), Get Demographics has two more, see below.

| | | | |
| :--- | :--- | :--- | :--- |
| identifiersOnly | boolean | 0..1 | Instruct the Client Registry to return Patient Identifiers only when true. If not present, defaults to false. |
| withHistory | boolean | 0..1 | Boolean flag to return Patient's history. If missing, defaults to false. |

#### Metadata Out Parameters

Besides the mandatory parameters, the request search parameters are echoed back in the MetadataParametersOut resource with a parameter named requestParameters (which is a MetadataParametersIn resource).

| | | | |
| :--- | :--- | :--- | :--- |
| requestParameters | MetadataParametersIn | 1..1 | The request parameters are echoed back.. |

#### Examples

See [Get Demographics request](Bundle-GetDemographics-Request.md) example.
 See [Get Demographics response](Bundle-GetDemographics-Response.md) example.
 See [Get Demographics with history response](Bundle-GetDemographics-withHistory-Response.md) example.
 See [Get Demographics with PHN info response](Bundle-GetDemographics-withPHNInfo-Response.md) example.

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

