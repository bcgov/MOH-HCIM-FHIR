# BC Identifier Status - JSON Representation - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Identifier Status**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-identifier-status-extension.md) 
*  [Detailed Descriptions](StructureDefinition-bc-identifier-status-extension-definitions.md) 
*  [Mappings](StructureDefinition-bc-identifier-status-extension-mappings.md) 
*  [XML](StructureDefinition-bc-identifier-status-extension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-bc-identifier-status-extension.profile.ttl.md) 

## Extension: IdentifierStatusExtension - JSON Profile

| |
| :--- |
| Active as of 2025-10-07 |

JSON representation of the bc-identifier-status-extension extension.

[Raw json](StructureDefinition-bc-identifier-status-extension.json) | [Download](StructureDefinition-bc-identifier-status-extension.json)

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

