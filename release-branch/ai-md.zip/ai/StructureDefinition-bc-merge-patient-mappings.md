# PatientMerge - Mappings - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PatientMerge**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-merge-patient.md) 
*  [Detailed Descriptions](StructureDefinition-bc-merge-patient-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-bc-merge-patient.profile.xml.md) 
*  [JSON](StructureDefinition-bc-merge-patient.profile.json.md) 
*  [TTL](StructureDefinition-bc-merge-patient.profile.ttl.md) 

## Resource Profile: PatientMerge - Mappings

| |
| :--- |
| Active as of 2025-10-07 |

Mappings for the bc-merge-patient resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

