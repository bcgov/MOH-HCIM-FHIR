# HCIMPatientChangeSubscription - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HCIMPatientChangeSubscription**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-HCIMPatientChangeSubscription-definitions.md) 
*  [Mappings](StructureDefinition-HCIMPatientChangeSubscription-mappings.md) 
*  [Examples](StructureDefinition-HCIMPatientChangeSubscription-examples.md) 
*  [XML](StructureDefinition-HCIMPatientChangeSubscription.profile.xml.md) 
*  [JSON](StructureDefinition-HCIMPatientChangeSubscription.profile.json.md) 
*  [TTL](StructureDefinition-HCIMPatientChangeSubscription.profile.ttl.md) 

## Resource Profile: HCIMPatientChangeSubscription 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/HCIMPatientChangeSubscription | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:HCIMPatientChangeSubscription |

 
Profile on subscription for HCIM Patient Changes 

**Usages:**

* Examples for this Profile: [Subscription/SampleCompositeSubscriptionRequest](Subscription-SampleCompositeSubscriptionRequest.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/HCIMPatientChangeSubscription)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [BackportSubscription](http://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [BackportSubscription](http://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 4 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [BackportSubscription](http://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [BackportSubscription](http://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 4 elements

 

Other representations of profile: [CSV](StructureDefinition-HCIMPatientChangeSubscription.csv), [Excel](StructureDefinition-HCIMPatientChangeSubscription.xlsx), [Schematron](StructureDefinition-HCIMPatientChangeSubscription.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

