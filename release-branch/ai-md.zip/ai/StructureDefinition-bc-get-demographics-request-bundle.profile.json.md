# GetDemographicsRequestBundle - JSON Representation - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographicsRequestBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-get-demographics-request-bundle.md) 
*  [Detailed Descriptions](StructureDefinition-bc-get-demographics-request-bundle-definitions.md) 
*  [Mappings](StructureDefinition-bc-get-demographics-request-bundle-mappings.md) 
*  [Examples](StructureDefinition-bc-get-demographics-request-bundle-examples.md) 
*  [XML](StructureDefinition-bc-get-demographics-request-bundle.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-bc-get-demographics-request-bundle.profile.ttl.md) 

## Resource Profile: GetDemographicsRequestBundle - JSON Profile

| |
| :--- |
| Active as of 2025-10-07 |

JSON representation of the bc-get-demographics-request-bundle resource profile.

[Raw json](StructureDefinition-bc-get-demographics-request-bundle.json) | [Download](StructureDefinition-bc-get-demographics-request-bundle.json)

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

