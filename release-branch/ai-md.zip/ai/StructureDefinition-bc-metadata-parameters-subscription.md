# MetadataParametersSubscription - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MetadataParametersSubscription**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-metadata-parameters-subscription-definitions.md) 
*  [Mappings](StructureDefinition-bc-metadata-parameters-subscription-mappings.md) 
*  [XML](StructureDefinition-bc-metadata-parameters-subscription.profile.xml.md) 
*  [JSON](StructureDefinition-bc-metadata-parameters-subscription.profile.json.md) 
*  [TTL](StructureDefinition-bc-metadata-parameters-subscription.profile.ttl.md) 

## Resource Profile: MetadataParametersSubscription 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-subscription | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:MetadataParametersSubscription |

 
Parameters profile for BC meta data when a subscription response is sent. 

**Usages:**

* Use this Profile: [SubscriptionNotificationBundle](StructureDefinition-bc-subscription-notification-bundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-metadata-parameters-subscription)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

**Summary**

Mandatory: 7 elements
 Must-Support: 9 elements
 Prohibited: 6 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Parameters.parameter
* The element 1 is sliced based on the value of Parameters.parameter.value[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

**Summary**

Mandatory: 7 elements
 Must-Support: 9 elements
 Prohibited: 6 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Parameters.parameter
* The element 1 is sliced based on the value of Parameters.parameter.value[x]

 

Other representations of profile: [CSV](StructureDefinition-bc-metadata-parameters-subscription.csv), [Excel](StructureDefinition-bc-metadata-parameters-subscription.xlsx), [Schematron](StructureDefinition-bc-metadata-parameters-subscription.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

