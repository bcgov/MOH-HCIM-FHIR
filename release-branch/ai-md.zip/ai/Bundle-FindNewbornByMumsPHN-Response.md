# FindNewbornByMumsPHN-Response - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FindNewbornByMumsPHN-Response**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-FindNewbornByMumsPHN-Response.xml.md) 
*  [JSON](Bundle-FindNewbornByMumsPHN-Response.json.md) 
*  [TTL](Bundle-FindNewbornByMumsPHN-Response.ttl.md) 

## Example Bundle: FindNewbornByMumsPHN-Response

Profile: [SearchResponseBundle](StructureDefinition-bc-search-response-bundle.md)

Bundle FindNewbornByMumsPHN-Response of type searchset

-------

Entry 1 - fullUrl = urn:uuid:b46f78e1-cfa1-41a6-ba9c-fafe6822791a

Resource Parameters:

> 

Profile: [MetadataParametersOut](StructureDefinition-bc-metadata-parameters-out.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:c3e604ec-0917-41a8-9d90-1da8e6611234

Search:Mode = outcome

Resource OperationOutcome:

> All OK

-------

Entry 3 - fullUrl = urn:uuid:d71c7185-8419-455d-bd39-cb184193ddbc

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Baby Girl Shawley Female, DoB: 2023-01-22 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id#9999999991 (use: official, period: 2023-01-23 13:58:38-0800 --> (ongoing)))
-------

-------

Entry 4 - fullUrl = urn:uuid:c7c91331-ef61-4153-b01e-b8d6447b66c5

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Baby Girl Shawley Female, DoB: 2023-01-22 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id#9999999992 (use: official, period: 2023-01-23 13:58:38-0800 --> (ongoing)))
-------

-------

Entry 5 - fullUrl = urn:uuid:beda6325-3140-444e-af5b-0f6c320b98d1

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Dietrich Shawley Female, DoB: 2022-12-17 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id#9999999999 (use: official, period: 2023-01-23 13:58:38-0800 --> (ongoing)))
-------

-------

Entry 6 - fullUrl = urn:uuid:13cb4c36-102d-49c7-9f2e-f652ece39ecf

Search:Mode = include

Resource RelatedPerson:

> **patient**:[urn:uuid:71092811-55f9-4e1f-8754-a6828da1d51c](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=urn:uuid:71092811-55f9-4e1f-8754-a6828da1d51c)**relationship**:natural mother

-------

Entry 7 - fullUrl = urn:uuid:613f5d13-9753-4c0c-89f9-f2bce0622721

Search:Mode = include

Resource RelatedPerson:

> **patient**:[urn:uuid:69b91ae6-e147-4dd0-abe7-8912ec301fd9](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=urn:uuid:69b91ae6-e147-4dd0-abe7-8912ec301fd9)**relationship**:natural mother

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

