# BC Death Verified Flag History - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Death Verified Flag History**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-death-verified-flag-history-extension-definitions.md) 
*  [Mappings](StructureDefinition-bc-death-verified-flag-history-extension-mappings.md) 
*  [XML](StructureDefinition-bc-death-verified-flag-history-extension.profile.xml.md) 
*  [JSON](StructureDefinition-bc-death-verified-flag-history-extension.profile.json.md) 
*  [TTL](StructureDefinition-bc-death-verified-flag-history-extension.profile.ttl.md) 

## Extension: BC Death Verified Flag History 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-verified-flag-history-extension | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:DeathVerifiedFlagHistoryExtension |

This extension allows the Client Registry to include historical death flags in a single Patient resource.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [BC Death Verified Flag](StructureDefinition-bc-death-verified-flag-extension.md)
* Examples for this Extension: [Bundle/GetDemographics-withPHNInfo-Response](Bundle-GetDemographics-withPHNInfo-Response.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-death-verified-flag-history-extension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Complex Extension: This extension allows the Client Registry to include historical death flags in a single Patient resource.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Complex Extension: This extension allows the Client Registry to include historical death flags in a single Patient resource.

 

Other representations of profile: [CSV](StructureDefinition-bc-death-verified-flag-history-extension.csv), [Excel](StructureDefinition-bc-death-verified-flag-history-extension.xlsx), [Schematron](StructureDefinition-bc-death-verified-flag-history-extension.sch) 

#### Constraints

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

