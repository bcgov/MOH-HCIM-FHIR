# BC Client registry identifier status code system - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Client registry identifier status code system**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-bc-identifier-status-code-system.xml.md) 
*  [JSON](CodeSystem-bc-identifier-status-code-system.json.md) 
*  [TTL](CodeSystem-bc-identifier-status-code-system.ttl.md) 

## CodeSystem: BC Client registry identifier status code system 

| | |
| :--- | :--- |
| *Official URL*:https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-identifier-status-code-system | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:IdentifierStatusCS |

 
BC Client registry identifier status code system. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [IdentifierStatusVS](ValueSet-bc-identifier-status-value-set.md)

This case-sensitive code system `https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-identifier-status-code-system` defines the following codes:

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

