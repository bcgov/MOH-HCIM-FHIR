# ClientRegistryPatient - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ClientRegistryPatient**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-patient-definitions.md) 
*  [Mappings](StructureDefinition-bc-patient-mappings.md) 
*  [Examples](StructureDefinition-bc-patient-examples.md) 
*  [XML](StructureDefinition-bc-patient.profile.xml.md) 
*  [JSON](StructureDefinition-bc-patient.profile.json.md) 
*  [TTL](StructureDefinition-bc-patient.profile.ttl.md) 

## Resource Profile: ClientRegistryPatient 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:ClientRegistryPatient |

 
General constraints on the Patient resource for use in the BC Client Registry project. 

Patient is a core resource of the Client Registry FHIR implementation. Patients are returned by queries ([Find Candidates](OperationDefinition-bc-patient-find-candidates.md) and [Get Demographics](OperationDefinition-bc-patient-get-demographics.md)) and modified or updated by [AddPatient](OperationDefinition-bc-patient-add.md), [RevisePatient](OperationDefinition-bc-patient-revise.md) and [MergePatient](OperationDefinition-bc-patient-merge.md) FHIR Operations. This profile primarily adds extensions to elements that the core Patient resource does not include such as business dates.

In the context of the Get Demographics request message, the Patient resource must have either a resource id ( Patient.id) or an identifier(Patient.identifier) in the same request. If they are both supplied the message will be rejected.

In the context of the Revise Person and Merge request message, the Patient resource must have an effective date (which is the business date when the patient presented for service, not a real time date).

**Usages:**

* Use this Profile: [AddRequestBundle](StructureDefinition-bc-add-request-bundle.md), [AddResponseBundle](StructureDefinition-bc-add-response-bundle.md), [FindCandidatesRequestBundle](StructureDefinition-bc-find-candidates-request-bundle.md), [GetDemographicsRequestBundle](StructureDefinition-bc-get-demographics-request-bundle.md)...Show 4 more,[ReviseRequestBundle](StructureDefinition-bc-revise-request-bundle.md),[ReviseResponseBundle](StructureDefinition-bc-revise-response-bundle.md),[SearchResponseBundle](StructureDefinition-bc-search-response-bundle.md)and[SubscriptionNotificationBundle](StructureDefinition-bc-subscription-notification-bundle.md)
* Examples for this Profile: [Patient/Force-Create-Request](Patient-Force-Create-Request.md), [Patient/Newborn-Request](Patient-Newborn-Request.md), [Patient/Patient-GetDemographics-Example](Patient-Patient-GetDemographics-Example.md), [Patient/Revise-Request-No-SRI-RESTful](Patient-Revise-Request-No-SRI-RESTful.md) and [Patient/Revise-Request](Patient-Revise-Request.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-patient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

**Summary**

Must-Support: 26 elements

**Structures**

This structure refers to these other structures:

* [Identifier DataType Profile (CA Baseline)(http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)

**Extensions**

This structure refers to these extensions:

* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension](StructureDefinition-bc-business-period-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension](StructureDefinition-bc-sourceId-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension](StructureDefinition-bc-identifier-status-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-gender-history-extension](StructureDefinition-bc-gender-history-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-birthdate-history-extension](StructureDefinition-bc-birthdate-history-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-date-history-extension](StructureDefinition-bc-death-date-history-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-verified-flag-extension](StructureDefinition-bc-death-verified-flag-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension](StructureDefinition-bc-validation-status-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-multiplebirth-history-extension](StructureDefinition-bc-multiplebirth-history-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-merge-status-extension](StructureDefinition-bc-merge-status-extension.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

**Summary**

Must-Support: 26 elements

**Structures**

This structure refers to these other structures:

* [Identifier DataType Profile (CA Baseline)(http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)

**Extensions**

This structure refers to these extensions:

* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension](StructureDefinition-bc-business-period-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-sourceId-extension](StructureDefinition-bc-sourceId-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-identifier-status-extension](StructureDefinition-bc-identifier-status-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-gender-history-extension](StructureDefinition-bc-gender-history-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-birthdate-history-extension](StructureDefinition-bc-birthdate-history-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-date-history-extension](StructureDefinition-bc-death-date-history-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-verified-flag-extension](StructureDefinition-bc-death-verified-flag-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension](StructureDefinition-bc-validation-status-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-multiplebirth-history-extension](StructureDefinition-bc-multiplebirth-history-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-merge-status-extension](StructureDefinition-bc-merge-status-extension.md)

 

Other representations of profile: [CSV](StructureDefinition-bc-patient.csv), [Excel](StructureDefinition-bc-patient.xlsx), [Schematron](StructureDefinition-bc-patient.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

