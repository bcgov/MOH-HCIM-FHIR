# Revise-Async-ACK - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Revise-Async-ACK**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-Revise-Async-ACK.xml.md) 
*  [JSON](Bundle-Revise-Async-ACK.json.md) 
*  [TTL](Bundle-Revise-Async-ACK.ttl.md) 

## Example Bundle: Revise-Async-ACK

Profile: [AsyncAckBundle](StructureDefinition-bc-async-ack-response-bundle.md)

Bundle Revise-Async-ACK of type collection

-------

Entry 1 - fullUrl = urn:uuid:e12213c8-9351-4a9b-94cb-54d3710be5b4

Resource Parameters:

> 

Profile: [MetadataParametersAsync](StructureDefinition-bc-metadata-parameter-async-response.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:e12213c8-9351-4a9b-94cb-54d3710b9876

Resource OperationOutcome:

> All OK

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

