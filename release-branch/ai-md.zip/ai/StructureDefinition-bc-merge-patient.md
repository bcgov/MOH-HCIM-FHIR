# PatientMerge - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PatientMerge**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-merge-patient-definitions.md) 
*  [Mappings](StructureDefinition-bc-merge-patient-mappings.md) 
*  [XML](StructureDefinition-bc-merge-patient.profile.xml.md) 
*  [JSON](StructureDefinition-bc-merge-patient.profile.json.md) 
*  [TTL](StructureDefinition-bc-merge-patient.profile.ttl.md) 

## Resource Profile: PatientMerge 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-merge-patient | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:PatientMerge |

 
General constraints on the Patient resource for use in the BC Client Registry project Merge Operation. 

**Usages:**

* Use this Profile: [MergeRequestBundle](StructureDefinition-bc-merge-request-bundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-merge-patient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

#### Terminology Bindings (Differential)

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

**Summary**

Mandatory: 1 element(2 nested mandatory elements)
 Must-Support: 13 elements

**Structures**

This structure refers to these other structures:

* [Identifier DataType Profile (CA Baseline)(http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)

**Extensions**

This structure refers to these extensions:

* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension](StructureDefinition-bc-business-period-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-verified-flag-extension](StructureDefinition-bc-death-verified-flag-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension](StructureDefinition-bc-validation-status-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-merge-status-extension](StructureDefinition-bc-merge-status-extension.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

#### Terminology Bindings (Differential)

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [PatientProfile](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-patient) 

**Summary**

Mandatory: 1 element(2 nested mandatory elements)
 Must-Support: 13 elements

**Structures**

This structure refers to these other structures:

* [Identifier DataType Profile (CA Baseline)(http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/StructureDefinition/profile-identifier)

**Extensions**

This structure refers to these extensions:

* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension](StructureDefinition-bc-business-period-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-death-verified-flag-extension](StructureDefinition-bc-death-verified-flag-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-validation-status-extension](StructureDefinition-bc-validation-status-extension.md)
* [http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-merge-status-extension](StructureDefinition-bc-merge-status-extension.md)

 

Other representations of profile: [CSV](StructureDefinition-bc-merge-patient.csv), [Excel](StructureDefinition-bc-merge-patient.xlsx), [Schematron](StructureDefinition-bc-merge-patient.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

