# Revise Patient - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Revise Patient**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](OperationDefinition-bc-patient-revise.xml.md) 
*  [JSON](OperationDefinition-bc-patient-revise.json.md) 
*  [TTL](OperationDefinition-bc-patient-revise.ttl.md) 

## OperationDefinition: Revise Patient 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/OperationDefinition/bc-patient-revise | *Version*:1.0.0 |
| Draft as of 2025-10-07 | *Computable Name*:RevisePatient |

 
This operation is used to revise a patient's demographics. 

This is the Revise Patient operation. The request is a Bundle and is used for incoming updates and also used for Patient notifications (outbound messages, from the Client Registry to a connected partner)

A Patient resource is required to update or add a patient. If updating, the empty attributes in the Patient resource will be deleted by the Client Registry.

Please refer also to the [Identifiers](identifiers.md) page to find more details regarding how to use Identifier in your query.

URL: [base]/Patient/$RevisePatient

Input parameters Profile:[ReviseRequestBundle](StructureDefinition-bc-revise-request-bundle.md)

Output parameters Profile:[ReviseResponseBundle](StructureDefinition-bc-revise-response-bundle.md)

### Parameters

* **Use**: IN
  * **Name**: ReviseRequestBundle
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Bundle](http://hl7.org/fhir/R4/bundle.html)
  * **Binding**: 
  * **Documentation**: The RevisePatient operation request Bundle.
* **Use**: OUT
  * **Name**: ReviseResponseBundle
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Bundle](http://hl7.org/fhir/R4/bundle.html)
  * **Binding**: 
  * **Documentation**: The RevisePatient operation response Bundle.

### Notes:

#### In Bundle Entries

| | | |
| :--- | :--- | :--- |
| 1..1 | MetadataParametersIn | See[profile](StructureDefinition-bc-metadata-parameters-in.md). |
| 1..1 | ClientRegistryPatient | See[profile](StructureDefinition-bc-patient.md). |

#### Out Bundle Entries

| | | |
| :--- | :--- | :--- |
| 1..1 | MetadataParametersOut | See[profile](StructureDefinition-bc-metadata-parameters-out.md). |
| 1,,1 | OperationOutcome | An OperationOutcome resource that has warnings and errors regarding the operation requested. |
| 0..1 | ClientRegistryPatient | See[profile](StructureDefinition-bc-patient.md). |

#### Metadata In Parameters

Besides the two mandatory name-value pairs, see [parameters in](StructureDefinition-bc-metadata-parameters-in.md), Revise Patient has no additional paramters.

#### Metadata Out Parameters

Besides the mandatory parameters, Revise Patient has no additional out parameters. See [parameters out](StructureDefinition-bc-metadata-parameters-out.md)

#### Examples

See [Revise Patient request](Bundle-Revise-withMaxData-Request.md) example.
 See [Revise Patient response](Bundle-Revise-Response.md) example.

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

