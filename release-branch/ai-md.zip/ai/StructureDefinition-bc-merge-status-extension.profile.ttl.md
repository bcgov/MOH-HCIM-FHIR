# BC Merge Status Code - TTL Representation - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Merge Status Code**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-merge-status-extension.md) 
*  [Detailed Descriptions](StructureDefinition-bc-merge-status-extension-definitions.md) 
*  [Mappings](StructureDefinition-bc-merge-status-extension-mappings.md) 
*  [XML](StructureDefinition-bc-merge-status-extension.profile.xml.md) 
*  [JSON](StructureDefinition-bc-merge-status-extension.profile.json.md) 
*  [TTL](#) 

## Extension: MergeStatusExtension - TTL Profile

| |
| :--- |
| Active as of 2025-10-07 |

TTL representation of the bc-merge-status-extension extension.

[Raw ttl](StructureDefinition-bc-merge-status-extension.ttl) | [Download](StructureDefinition-bc-merge-status-extension.ttl)

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

