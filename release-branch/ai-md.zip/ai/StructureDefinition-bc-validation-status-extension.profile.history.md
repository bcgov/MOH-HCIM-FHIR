#  - BC Client Registry FHIR Implementation Guide v1.0.0

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-validation-status-extension.md) 
*  [Detailed Descriptions](StructureDefinition-bc-validation-status-extension-definitions.md) 
*  [Mappings](StructureDefinition-bc-validation-status-extension-mappings.md) 
*  [XML](StructureDefinition-bc-validation-status-extension.profile.xml.md) 
*  [JSON](StructureDefinition-bc-validation-status-extension.profile.json.md) 
*  [TTL](StructureDefinition-bc-validation-status-extension.profile.ttl.md) 

## Extension: ValidationStatusExtension - Change History

| |
| :--- |
| Active as of 2025-10-07 |

Changes in the bc-validation-status-extension extension.

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

