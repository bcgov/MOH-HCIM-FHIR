# Find Candidates By Example - Testing - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Find Candidates By Example**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](OperationDefinition-bc-patient-find-candidates.md) 
*  [XML](OperationDefinition-bc-patient-find-candidates.xml.md) 
*  [JSON](OperationDefinition-bc-patient-find-candidates.json.md) 
*  [TTL](OperationDefinition-bc-patient-find-candidates.ttl.md) 

## OperationDefinition: Find Candidates By Example - Testing 

| |
| :--- |
| Active as of 2025-10-07 |

### Test Plans

**No test plans are currently available for the OperationDefinition.**

### Test Scripts

**No test scripts are currently available for the OperationDefinition.**

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

