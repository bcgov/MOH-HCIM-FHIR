# FindNewbornByMumsPHN-Response - TTL Representation - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FindNewbornByMumsPHN-Response**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](Bundle-FindNewbornByMumsPHN-Response.md) 
*  [XML](Bundle-FindNewbornByMumsPHN-Response.xml.md) 
*  [JSON](Bundle-FindNewbornByMumsPHN-Response.json.md) 
*  [TTL](#) 

## : FindNewbornByMumsPHN-Response - TTL Representation

[Raw ttl](Bundle-FindNewbornByMumsPHN-Response.ttl) | [Download](Bundle-FindNewbornByMumsPHN-Response.ttl)

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

