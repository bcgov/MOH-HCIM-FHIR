# SearchResponseBundle - Examples - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SearchResponseBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-search-response-bundle.md) 
*  [Detailed Descriptions](StructureDefinition-bc-search-response-bundle-definitions.md) 
*  [Mappings](StructureDefinition-bc-search-response-bundle-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-bc-search-response-bundle.profile.xml.md) 
*  [JSON](StructureDefinition-bc-search-response-bundle.profile.json.md) 
*  [TTL](StructureDefinition-bc-search-response-bundle.profile.ttl.md) 

## Resource Profile: SearchResponseBundle - Examples

| |
| :--- |
| Active as of 2025-10-07 |

Examples for the bc-search-response-bundle Profile.

| |
| :--- |
| [FindCandidates-Response](Bundle-FindCandidates-Response.md) |
| [FindNewbornByMumsPHN-Response](Bundle-FindNewbornByMumsPHN-Response.md) |
| [GetDemographics-Response-Masked](Bundle-GetDemographics-Response-Masked.md) |
| [GetDemographics-Response](Bundle-GetDemographics-Response.md) |
| [GetDemographics-withHistory-Response](Bundle-GetDemographics-withHistory-Response.md) |
| [GetDemographics-withPHNInfo-Response](Bundle-GetDemographics-withPHNInfo-Response.md) |

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

