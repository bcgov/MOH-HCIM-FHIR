# Revise-withMaxData-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Revise-withMaxData-Request**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-Revise-withMaxData-Request.xml.md) 
*  [JSON](Bundle-Revise-withMaxData-Request.json.md) 
*  [TTL](Bundle-Revise-withMaxData-Request.ttl.md) 

## Example Bundle: Revise-withMaxData-Request

Profile: [ReviseRequestBundle](StructureDefinition-bc-revise-request-bundle.md)

Bundle Revise-withMaxData-Request of type collection

-------

Entry 1 - fullUrl = urn:uuid:e12213c8-9351-4a9b-94cb-54d3710be5b4

Resource Parameters:

> 

Profile: [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:112a2ba8-c3c9-4b08-8cfd-f025b85b3e0c

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Geraldine Celestine Iye Banek Female, DoB: 1956-12-17 ( Account number (use: official, ))
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

