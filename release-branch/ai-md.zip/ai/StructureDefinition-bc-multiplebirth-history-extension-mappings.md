# BC Multiple Birth History - Mappings - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Multiple Birth History**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-multiplebirth-history-extension.md) 
*  [Detailed Descriptions](StructureDefinition-bc-multiplebirth-history-extension-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-bc-multiplebirth-history-extension.profile.xml.md) 
*  [JSON](StructureDefinition-bc-multiplebirth-history-extension.profile.json.md) 
*  [TTL](StructureDefinition-bc-multiplebirth-history-extension.profile.ttl.md) 

## Extension: MultipleBirthHistoryExtension - Mappings

| |
| :--- |
| Active as of 2025-10-07 |

Mappings for the bc-multiplebirth-history-extension extension.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

