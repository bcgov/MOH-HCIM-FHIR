# FindCandidatesRequestBundle - Mappings - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FindCandidatesRequestBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-find-candidates-request-bundle.md) 
*  [Detailed Descriptions](StructureDefinition-bc-find-candidates-request-bundle-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-bc-find-candidates-request-bundle-examples.md) 
*  [XML](StructureDefinition-bc-find-candidates-request-bundle.profile.xml.md) 
*  [JSON](StructureDefinition-bc-find-candidates-request-bundle.profile.json.md) 
*  [TTL](StructureDefinition-bc-find-candidates-request-bundle.profile.ttl.md) 

## Resource Profile: FindCandidatesRequestBundle - Mappings

| |
| :--- |
| Active as of 2025-10-07 |

Mappings for the bc-find-candidates-request-bundle resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

