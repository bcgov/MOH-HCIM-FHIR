# BC Merge Status Code - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Merge Status Code**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-merge-status-extension-definitions.md) 
*  [Mappings](StructureDefinition-bc-merge-status-extension-mappings.md) 
*  [XML](StructureDefinition-bc-merge-status-extension.profile.xml.md) 
*  [JSON](StructureDefinition-bc-merge-status-extension.profile.json.md) 
*  [TTL](StructureDefinition-bc-merge-status-extension.profile.ttl.md) 

## Extension: BC Merge Status Code 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-merge-status-extension | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:MergeStatusExtension |

A code that represents the Merge status of the Patient.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [PatientMerge](StructureDefinition-bc-merge-patient.md) and [ClientRegistryPatient](StructureDefinition-bc-patient.md)
* Examples for this Extension: [Parameters/Merge-Request](Parameters-Merge-Request.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-merge-status-extension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type code: A code that represents the Merge status of the Patient.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type code: A code that represents the Merge status of the Patient.

 

Other representations of profile: [CSV](StructureDefinition-bc-merge-status-extension.csv), [Excel](StructureDefinition-bc-merge-status-extension.xlsx), [Schematron](StructureDefinition-bc-merge-status-extension.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

