# BC Business Dates - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Business Dates**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-business-period-extension-definitions.md) 
*  [Mappings](StructureDefinition-bc-business-period-extension-mappings.md) 
*  [XML](StructureDefinition-bc-business-period-extension.profile.xml.md) 
*  [JSON](StructureDefinition-bc-business-period-extension.profile.json.md) 
*  [TTL](StructureDefinition-bc-business-period-extension.profile.ttl.md) 

## Extension: BC Business Dates 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-business-period-extension | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:BusinessPeriodExtension |

The effective dates for the parent element.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [BC Birth Date History](StructureDefinition-bc-birthdate-history-extension.md), [BC Death Date History](StructureDefinition-bc-death-date-history-extension.md), [BC Death Verified Flag](StructureDefinition-bc-death-verified-flag-extension.md), [BC Death Verified Flag History](StructureDefinition-bc-death-verified-flag-history-extension.md)...Show 4 more,[BC Gender History](StructureDefinition-bc-gender-history-extension.md),[PatientMerge](StructureDefinition-bc-merge-patient.md),[BC Multiple Birth History](StructureDefinition-bc-multiplebirth-history-extension.md)and[ClientRegistryPatient](StructureDefinition-bc-patient.md)
* Examples for this Extension: [Bundle/FindCandidates-Response](Bundle-FindCandidates-Response.md), [Bundle/FindNewbornByMumsPHN-Response](Bundle-FindNewbornByMumsPHN-Response.md), [Bundle/GetDemographics-Request-By-SSRI](Bundle-GetDemographics-Request-By-SSRI.md), [Bundle/GetDemographics-Response](Bundle-GetDemographics-Response.md)...Show 10 more,[Bundle/GetDemographics-withHistory-Response](Bundle-GetDemographics-withHistory-Response.md),[Bundle/GetDemographics-withPHNInfo-Response](Bundle-GetDemographics-withPHNInfo-Response.md),[Bundle/Revise-Request-No-SRI](Bundle-Revise-Request-No-SRI.md),[Parameters/Merge-Min-Request](Parameters-Merge-Min-Request.md),[Parameters/Merge-Request](Parameters-Merge-Request.md),[Patient/Force-Create-Request](Patient-Force-Create-Request.md),[Patient/Newborn-Request](Patient-Newborn-Request.md),[Patient/Patient-GetDemographics-Example](Patient-Patient-GetDemographics-Example.md),[Patient/Revise-Request-No-SRI-RESTful](Patient-Revise-Request-No-SRI-RESTful.md)and[Patient/Revise-Request](Patient-Revise-Request.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-business-period-extension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Period: The effective dates for the parent element.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Period: The effective dates for the parent element.

 

Other representations of profile: [CSV](StructureDefinition-bc-business-period-extension.csv), [Excel](StructureDefinition-bc-business-period-extension.xlsx), [Schematron](StructureDefinition-bc-business-period-extension.sch) 

#### Constraints

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

