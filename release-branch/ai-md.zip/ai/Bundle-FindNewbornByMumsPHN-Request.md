# FindNewbornByMumsPHN-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FindNewbornByMumsPHN-Request**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-FindNewbornByMumsPHN-Request.xml.md) 
*  [JSON](Bundle-FindNewbornByMumsPHN-Request.json.md) 
*  [TTL](Bundle-FindNewbornByMumsPHN-Request.ttl.md) 

## Example Bundle: FindNewbornByMumsPHN-Request

Profile: [FindCandidatesRequestBundle](StructureDefinition-bc-find-candidates-request-bundle.md)

Bundle FindNewbornByMumsPHN-Request of type collection

-------

Entry 1 - fullUrl = urn:uuid:b46f78e1-cfa1-41a6-ba9c-fafe6822791a

Resource Parameters:

> 

Profile: [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:e7ae452f-9076-4cd6-958f-1d1c55d34c38

Resource RelatedPerson:

> **identifier**:`https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id`/9999999999**patient**:[Patient/e418862f-1759-42de-98a9-00433a779e9b](https://simplifier.net/resolve?scope=hl7.fhir.ca.baseline@1.2.0&canonical=http://hl7.org/fhir/ca/baseline/Patient/e418862f-1759-42de-98a9-00433a779e9b)**relationship**:natural mother

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

