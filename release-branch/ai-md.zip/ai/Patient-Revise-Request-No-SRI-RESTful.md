# Revise-Request-No-SRI-RESTful - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Revise-Request-No-SRI-RESTful**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Patient-Revise-Request-No-SRI-RESTful.xml.md) 
*  [JSON](Patient-Revise-Request-No-SRI-RESTful.json.md) 
*  [TTL](Patient-Revise-Request-No-SRI-RESTful.ttl.md) 

## Example Patient: Revise-Request-No-SRI-RESTful

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Proinnsias Edmon Beartlaidh Tabatabai Female, DoB: 1996-02-18 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-msp-eligibility-id#?ngen-9? (use: official, ))

-------

| | |
| :--- | :--- |
| Alt. Name: | Victor (Nickname) |
| Contact Detail | * ph: 3104702526(Mobile)
* ph: 3366898069(Home)
* ph: 2544265519(Work)
* [Constance.Besarra@cgi.com](mailto:Constance.Besarra@cgi.com)
* [Hank.Avey@cgi.com](mailto:Hank.Avey@cgi.com)
* [Nerissa.Friede@cgi.com](mailto:Nerissa.Friede@cgi.com)
* 7562 Railroad street Calistoga BC V5QOX7 CA 
* 27523 Oak street Topmost BC V4IUH0 CA 
 |
| [BC Business Dates](StructureDefinition-bc-business-period-extension.md) | 2024-11-28 06:22:01-0800 --> (ongoing) |

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

