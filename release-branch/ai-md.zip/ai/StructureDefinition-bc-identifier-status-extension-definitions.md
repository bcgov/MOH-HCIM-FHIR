# BC Identifier Status - Definitions - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Identifier Status**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-identifier-status-extension.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-bc-identifier-status-extension-mappings.md) 
*  [XML](StructureDefinition-bc-identifier-status-extension.profile.xml.md) 
*  [JSON](StructureDefinition-bc-identifier-status-extension.profile.json.md) 
*  [TTL](StructureDefinition-bc-identifier-status-extension.profile.ttl.md) 

## Extension: IdentifierStatusExtension - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-07 |

Definitions for the bc-identifier-status-extension extension.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

