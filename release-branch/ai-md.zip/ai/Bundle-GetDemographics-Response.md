# GetDemographics-Response - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographics-Response**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-GetDemographics-Response.xml.md) 
*  [JSON](Bundle-GetDemographics-Response.json.md) 
*  [TTL](Bundle-GetDemographics-Response.ttl.md) 

## Example Bundle: GetDemographics-Response

Profile: [SearchResponseBundle](StructureDefinition-bc-search-response-bundle.md)

Bundle GetDemographics-Response of type searchset

-------

Entry 1 - fullUrl = urn:uuid:289d85b9-43a4-4902-9b52-76cb1f02ea69

Resource Parameters:

> 

Profile: [MetadataParametersOut](StructureDefinition-bc-metadata-parameters-out.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:f156cec9-77fe-40d2-a023-71f1442d4599

Search:Mode = outcome

Resource OperationOutcome:

> All OK

-------

Entry 3 - fullUrl = urn:uuid:27fb3c46-a6ea-4986-8238-d94d6655cc1d

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Benedetta Wuliton Ararinda Colpitts Male, DoB: 2005-05-24 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id#9999999999 (use: official, ))
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

