# BC Client Registry Operation Outcome details code system - JSON Representation - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Client Registry Operation Outcome details code system**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](CodeSystem-bc-operation-outcome-details-code-system.md) 
*  [XML](CodeSystem-bc-operation-outcome-details-code-system.xml.md) 
*  [JSON](#) 
*  [TTL](CodeSystem-bc-operation-outcome-details-code-system.ttl.md) 

## : BC Client Registry Operation Outcome details code system - JSON Representation

| |
| :--- |
| Active as of 2025-10-07 |

[Raw json](CodeSystem-bc-operation-outcome-details-code-system.json) | [Download](CodeSystem-bc-operation-outcome-details-code-system.json)

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

