# AddPatient-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AddPatient-Request**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-AddPatient-Request.xml.md) 
*  [JSON](Bundle-AddPatient-Request.json.md) 
*  [TTL](Bundle-AddPatient-Request.ttl.md) 

## Example Bundle: AddPatient-Request

This is an example of the AddPatient Operation used by connected partners to 'force create' a PHN.

The **first** resource is a Parameters (MetadataParametersIn) with message ID and date and time.

The **second** resource is the Patient (ClientRegistryPatient) with the patient's information.

Profile: [AddRequestBundle](StructureDefinition-bc-add-request-bundle.md)

Bundle AddPatient-Request of type collection

-------

Entry 1 - fullUrl = urn:uuid:0185235c-f8ea-4107-8979-591ddc2df30b

Resource Parameters:

> 

Profile: [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:951b9e8e-5c78-44d5-91b1-ad6fb748de4b

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Legarra Antonin Cecily Gillette Female, DoB: 1971-01-09 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-msp-eligibility-id#9455882493 (use: official, ))
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

