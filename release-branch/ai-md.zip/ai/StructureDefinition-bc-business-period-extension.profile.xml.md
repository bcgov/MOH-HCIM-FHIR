# BC Business Dates - XML Representation - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Business Dates**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-business-period-extension.md) 
*  [Detailed Descriptions](StructureDefinition-bc-business-period-extension-definitions.md) 
*  [Mappings](StructureDefinition-bc-business-period-extension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-bc-business-period-extension.profile.json.md) 
*  [TTL](StructureDefinition-bc-business-period-extension.profile.ttl.md) 

## Extension: BusinessPeriodExtension - XML Profile

| |
| :--- |
| Active as of 2025-10-07 |

XML representation of the bc-business-period-extension extension.

[Raw xml](StructureDefinition-bc-business-period-extension.xml) | [Download](StructureDefinition-bc-business-period-extension.xml)

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

