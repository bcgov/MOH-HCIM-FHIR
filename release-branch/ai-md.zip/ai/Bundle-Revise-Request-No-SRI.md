# Revise-Request-No-SRI - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Revise-Request-No-SRI**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-Revise-Request-No-SRI.xml.md) 
*  [JSON](Bundle-Revise-Request-No-SRI.json.md) 
*  [TTL](Bundle-Revise-Request-No-SRI.ttl.md) 

## Example Bundle: Revise-Request-No-SRI

Profile: [ReviseRequestBundle](StructureDefinition-bc-revise-request-bundle.md)

Bundle Revise-Request-No-SRI of type collection

-------

Entry 1 - fullUrl = urn:uuid:feece490-6a8b-48c3-bd35-6a16008c19ef

Resource Parameters:

> 

Profile: [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:23d2b2f0-7724-4959-9007-302b26499633

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Proinnsias Edmon Beartlaidh Tabatabai Female, DoB: 1996-02-18 ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-msp-eligibility-id#?ngen-9? (use: official, ))
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

