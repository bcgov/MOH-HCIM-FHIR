# SearchResponseBundle - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SearchResponseBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-search-response-bundle-definitions.md) 
*  [Mappings](StructureDefinition-bc-search-response-bundle-mappings.md) 
*  [Examples](StructureDefinition-bc-search-response-bundle-examples.md) 
*  [XML](StructureDefinition-bc-search-response-bundle.profile.xml.md) 
*  [JSON](StructureDefinition-bc-search-response-bundle.profile.json.md) 
*  [TTL](StructureDefinition-bc-search-response-bundle.profile.ttl.md) 

## Resource Profile: SearchResponseBundle 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-search-response-bundle | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:SearchResponseBundle |

 
A Bundle that is used in the Client Registry response to Find Candidates and Get Demographics queries. 

This Bundle profile applies to both Client Registry searches: Find Candidates and Get Demographics. The type is collection and two entries are mandatory: operationOutcome and parameters.

1. OperationOutcome is for warning or error messages.
1. The Parameters is for the response meta data such as dateTime and unique ID.

If the search matched one or more Patients, then there will be Bundle entries for Patients.

If the search criteria used mother's PHN then RelatedPerson resources may be returned, representing the mother.

**Usages:**

* Examples for this Profile: [Bundle/FindCandidates-Response](Bundle-FindCandidates-Response.md), [Bundle/FindNewbornByMumsPHN-Response](Bundle-FindNewbornByMumsPHN-Response.md), [Bundle/GetDemographics-Response-Masked](Bundle-GetDemographics-Response-Masked.md), [Bundle/GetDemographics-Response](Bundle-GetDemographics-Response.md)...Show 2 more,[Bundle/GetDemographics-withHistory-Response](Bundle-GetDemographics-withHistory-Response.md)and[Bundle/GetDemographics-withPHNInfo-Response](Bundle-GetDemographics-withPHNInfo-Response.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-search-response-bundle)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 3 elements(1 nested mandatory element)
 Must-Support: 8 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [ClientRegistryPatient(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient)](StructureDefinition-bc-patient.md)
* [MetadataParametersOut(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-out)](StructureDefinition-bc-metadata-parameters-out.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 3 elements(1 nested mandatory element)
 Must-Support: 8 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [ClientRegistryPatient(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient)](StructureDefinition-bc-patient.md)
* [MetadataParametersOut(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-out)](StructureDefinition-bc-metadata-parameters-out.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 

Other representations of profile: [CSV](StructureDefinition-bc-search-response-bundle.csv), [Excel](StructureDefinition-bc-search-response-bundle.xlsx), [Schematron](StructureDefinition-bc-search-response-bundle.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

