# Patient Notification - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Notification**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](OperationDefinition-bc-patient-notification.xml.md) 
*  [JSON](OperationDefinition-bc-patient-notification.json.md) 
*  [TTL](OperationDefinition-bc-patient-notification.ttl.md) 

## OperationDefinition: Patient Notification 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/OperationDefinition/bc-patient-notification | *Version*:1.0.0 |
| Draft as of 2025-10-07 | *Computable Name*:PatientNotification |

 
This operation is used notify a user that a patient's record has changed. 

> Note
This specification is currently published as a Draft Standard on the ministry GitHub and is not intended for implementation. Feedback is welcome but readers should understand that there is more work to be done in testing the profiles and operations defined in this guide. For more information, please see the Future Plans page in this guide.

This is the Patient Notification operation, aka Distribution.

A Patient resource is required to notify that a patient record has changed. This interaction is similar to RevisePatient, but the Client Registry is acting as the client.

URL: [base]/Patient/$PatientNotification

Input parameters Profile:[ReviseRequestBundle](StructureDefinition-bc-revise-request-bundle.md)

### Parameters

* **Use**: IN
  * **Name**: ReviseRequestBundle
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Bundle](http://hl7.org/fhir/R4/bundle.html)
  * **Binding**: 
  * **Documentation**: The request bundle.

### Notes:

The response to a Patient Notification Operation is a HTTP status code 200 on success without a body..

#### In Bundle Entries

| | | |
| :--- | :--- | :--- |
| 1..1 | MetadataParametersIn | See[profile](StructureDefinition-bc-metadata-parameters-in.md). |
| 1..1 | ClientRegistryPatient | See[profile](StructureDefinition-bc-patient.md). |

#### Out Bundle Entries

N/A

#### Metadata In Parameters

Besides the two mandatory name-value pairs, none.

#### Metadata Out Parameters

N/A

#### Examples

The following example is actually the revise patient example as it is identical to the notification request. See [Patient Notification request](Bundle-Revise-withMaxData-Request.md) example.

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

