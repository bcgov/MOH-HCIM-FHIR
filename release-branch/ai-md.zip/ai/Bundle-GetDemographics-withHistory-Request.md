# GetDemographics-withHistory-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographics-withHistory-Request**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-GetDemographics-withHistory-Request.xml.md) 
*  [JSON](Bundle-GetDemographics-withHistory-Request.json.md) 
*  [TTL](Bundle-GetDemographics-withHistory-Request.ttl.md) 

## Example Bundle: GetDemographics-withHistory-Request

Profile: [GetDemographicsRequestBundle](StructureDefinition-bc-get-demographics-request-bundle.md)

Bundle GetDemographics-withHistory-Request of type collection

-------

Entry 1 - fullUrl = urn:uuid:fb5ed5fa-e08f-4b88-948a-d81cd26d3453

Resource Parameters:

> 

Profile: [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:c83ebe98-0a68-42f1-b390-67323d4b5ce4

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Anonymous Patient (no stated gender), DoB Unknown ( https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-fv-source-patient-id#2701XI3IW2R95W87WH3H16082KJ2LEVENM0LNTW)
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

