# BC Client Registry Patient Change Notification Events Code System - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Client Registry Patient Change Notification Events Code System**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-bc-client-registry-patient-change-notification-events.xml.md) 
*  [JSON](CodeSystem-bc-client-registry-patient-change-notification-events.json.md) 
*  [TTL](CodeSystem-bc-client-registry-patient-change-notification-events.ttl.md) 

## CodeSystem: BC Client Registry Patient Change Notification Events Code System 

| | |
| :--- | :--- |
| *Official URL*:https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-client-registry-patient-change-notification-events | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:PatientChangeNotificationEvents |

 
Codes used to indicate that type of patient changes that a subscriber is interested in receiving. 

## Business Objective

This page outlines the objectives of each distribution profile and describes how the distribution service fulfills those objectives. A distribution profile consists of a collection of configurable options that allow a subscriber to customize how and when they will receive a distribution message. There is no limit to the number of distribution profiles for an organization.

### Distribution Profile Configuration Options

Each distribution profile has a number of options for its configuration.

**Organization** The Organization that this profile belongs to.

**Distribution Type** The distribution type that this profile subscribes to.

**Source Subscriptions** This option allows a source to limit the source systems that can trigger a notification. This means that changes to a source not in the subscription list will be ignored and not trigger a notification. The default setting is all sources.

**Source/Non-Source** **Source:** These require source context and are applicable when comparisons are made against records within EMPI and require the subscriber to be a source system in the EMPI. Subscribers will be notified that their data is out-of-sync with the composite view. These types of distributions will only notify the subscriber if they have a record in the affected entity. **Non-Source:** These do not require subscribers to have a record in the EMPI; instead, they are constrained to listening to all events that occur to a specific source in the EMPI. Note that it is possible to subscribe to multiple source systems.

**Data Permissions** A list of Source Identifiers that the subscribing organization has permission to view. Each organization has permission to see the MOH_CRS source (the source of the PHN) by default. The distribution service will filter out any Identifiers not in the permissions list. Currently, this permission list lives in the HCIM security settings for the organization and is applied to all services, not just the distribution service.

**Message Format** This is a new option for the profiles. The goal of this feature is to allow support for multiple messaging formats (such as HL7v3 and HL7 FHIR).

**Backwards Compatibility** One of the options would be a backward compatibility mode for HL7v3. If this project makes changes to the message structure or contents, there is a chance that existing systems will be incompatible; therefore, this mode will ensure that the distribution messages appear the same as prior to the distribution rewrite.

**Subscribed Regions** This new option would allow a subscriber to limit distributions by region. The distribution service would look at the home or mailing address for the affected record and send a notification if they are within a subscribed area. Filters would include:

* Region (i.e., postal code ranges)
* Province
* Country

## Distribution Types

The following tables describe each type of distribution and include a description with the following information:

* **Conditions**: Conditions that must be met for a distribution notification to occur; all conditions must apply
* **Contents**: Data attributes that will be populated in the distribution message

 This Code system is referenced in the content logical definition of the following value sets: 

* [PatientChangeNotificationEventsValueSet](ValueSet-bc-client-registry-patient-change-notification-events-value-set.md)

This case-sensitive code system `https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-client-registry-patient-change-notification-events` defines the following codes:

### Notes:

| | | |
| :--- | :--- | :--- |
| COMP | * An active (not merged or in an overlay task) MOH_CRS record exists in the entity set
* The source record must be active (not merged or in an overlay task)
* There are no source records in the entity with an overlay task
* The modified record that triggered the event is NOT new
* Source Distributions: The data attribute on the subscriber's source record is out-of-sync with the Composite View
* Non-Source Distributions: A data attribute has changed on a subscribed source system record
 | * All composite view Data Attributes: Name, Gender, Date of Birth, Date of Death, Deceased Indicator, Address, Phone Number, Email Address, and PHN
* Active and Merged SSRIs
* Last Modified Business Date
* Source: SRI of Source Record that is out-of-sync with the Composite View
* Non-Source: SRI of the modified Source Record
 |
| DEATH | * An active (not merged or in an overlay task) MOH_CRS record exists in the entity set
* There are no source records in the entity with an overlay task
* Source Distributions:
* Non-Source Distributions:
* Subscribe to one of the following:
* If the source has permission to provide the date of death to the composite view, the record cannot be a singleton; the member must be in an entity with a MOH_CRS record
 | * All composite view Data Attributes: Name, Gender, Date of Birth, Date of Death, Deceased Indicator, Address, Phone Number, Email Address, and PHN
* Active and Merged SSRIs
* Last Modified Business Date
* Source: SRI of Source Record in the entity set
 |
| NEW | * An active (not merged or in an overlay task) MOH_CRS record exists in the entity set
* There are no source records in the entity with an overlay task
* The event was generated by the creation of a new record
* The new record belongs to one of the source subscriptions from the profile
 | * All composite view Data Attributes: Name, Gender, Date of Birth, Date of Death, Deceased Indicator, Address, Phone Number, Email Address, and PHN
* Active and Merged Sub Source Record Identifiers (SSRIs)
* Mother's PHN
* Last Modified Business Date
 |
| NEWBORN | * An active (not merged or in an overlay task) MOH_CRS record exists in the entity set
* There are no source records in the entity with an overlay task
* The newborn record is new
* The declared name value is a Newborn Name
* The newborn record has a mother's PHN
* No death date and death indicator are present
 | * All composite view data attributes: Name, Gender, Date of Birth, Address, Phone Number, Email Address, and PHN
* Mother's PHN
* All SSRIs (Active and Merged)
* All Source Record Identifers (SRIs)
* Last Modified Business Date
 |
| NEWBORN_GENDER | * An active (not merged or in an overlay task) MOH_CRS record exists in the entity set
* There are no source records in the entity with an overlay task
* The newborn record is NOT new
* The declared name value is (or was) a Newborn Name
* The old gender value is Unknown
* The new gender value is NOT Uknown or Undifferentiated
* The intial newborn record must have a date of birth within the change window (5 days)
* No death date or death indicator is present
 | * All composite view Data Attributes: Name, Gender, Date of Birth, Address, Phone Number, Email Address, and PHN
* All SSRIs (Active and Merged)
* Mother's PHN
* Last Modified Business Date
 |
| PHN | * An active (not merged or in an overlay task) MOH_CRS record exists in the entity set
* There are no source records in the entity with an overlay task
* The source record must be an active (not merged or in an overlay task)
* The modified record that triggered the event is NOT new
* The PHN attribute on the subscriber's source record is out-of-sync with the composite view
 | * All composite view Data Attributes: Name, Gender, Date of Birth, Date of Death, Deceased Indicator, Address, Phone Number, Email Address, and PHN
* All SSRIs (Active and Merged)
* SRI of the source record that is out-of-sync with the PHN
* Last Modified Business Date
 |
| PHNJOIN | * An active (not merged or in an overlay task) MOH_CRS record exists in the entity set
* There are no source records in the entity with an overlay task
* The source record must be active (not merged or in an overlay task)
 | * All composite view Data Attributes: Name, Gender, Date of Birth, Date of Death, Deceased Indicator, Address, Phone Number, Email Address, or PHN
* All SSRIs (Active and Merged)
* SRI has joined the entity, or a PHN has joined the entity
* Last Modified Business Date
 |
| MERGE | *  An active (not merged or in an overlay task) MOH_CRS record exists in the entity set
* There are no source records in the entity with an overlay task
 | * All composite view Data Attributes: Name, Gender, Date of Birth, Date of Death, Deceased Indicator, Address, Phone Number, Email Address, and PHN
* All SSRIs (Active and Merged)
* All Merged identifiers (i.e., SRI, SSRI)
* Last Modified Business Date
 |
| SSRSISYNC | * There are no source records in the entity with an overlay task
* The source record that triggered the event is either Active or Merged
* A Parent Source Record is in the entity
* One or more child source systems are in the entity
* The parent source systems' list of SSRIs does not match the SRIs of the children source systems
 | * All composite view Data Attributes: Name, Gender, Date of Birth, Date of Death, Deceased Indicator, Address, Phone Number, Email Address, and PHN
* All SSRIs (Active and Merged)
* All SRIs (Active and Merged)
* Last Modified Business Date
 |

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

