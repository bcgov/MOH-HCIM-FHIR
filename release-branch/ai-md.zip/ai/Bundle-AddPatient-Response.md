# AddPatient-Response - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AddPatient-Response**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-AddPatient-Response.xml.md) 
*  [JSON](Bundle-AddPatient-Response.json.md) 
*  [TTL](Bundle-AddPatient-Response.ttl.md) 

## Example Bundle: AddPatient-Response

Profile: [AddResponseBundle](StructureDefinition-bc-add-response-bundle.md)

Bundle AddPatient-Response of type collection

-------

Entry 1 - fullUrl = urn:uuid:0185235c-f8ea-4107-8979-591ddc2df30b

Resource Parameters:

> 

Profile: [MetadataParametersOut](StructureDefinition-bc-metadata-parameters-out.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:0185235c-f8ea-4107-8979-591ddc2d1234

Resource OperationOutcome:

> All OK

-------

Entry 3 - fullUrl = urn:uuid:33f234d1-5781-45f2-8c8c-4b7cdd809078

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Anonymous Patient (no stated gender), DoB Unknown ( https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-patient-healthcare-id#9253484802 (use: official, period: 2023-01-23 13:46:27-0800 --> (ongoing)))
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

