# MergeResponseBundle - XML Representation - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MergeResponseBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-merge-response-bundle.md) 
*  [Detailed Descriptions](StructureDefinition-bc-merge-response-bundle-definitions.md) 
*  [Mappings](StructureDefinition-bc-merge-response-bundle-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-bc-merge-response-bundle.profile.json.md) 
*  [TTL](StructureDefinition-bc-merge-response-bundle.profile.ttl.md) 

## Resource Profile: MergeResponseBundle - XML Profile

| |
| :--- |
| Active as of 2025-10-07 |

XML representation of the bc-merge-response-bundle resource profile.

[Raw xml](StructureDefinition-bc-merge-response-bundle.xml) | [Download](StructureDefinition-bc-merge-response-bundle.xml)

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

