# ReviseResponseBundle - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ReviseResponseBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-revise-response-bundle-definitions.md) 
*  [Mappings](StructureDefinition-bc-revise-response-bundle-mappings.md) 
*  [Examples](StructureDefinition-bc-revise-response-bundle-examples.md) 
*  [XML](StructureDefinition-bc-revise-response-bundle.profile.xml.md) 
*  [JSON](StructureDefinition-bc-revise-response-bundle.profile.json.md) 
*  [TTL](StructureDefinition-bc-revise-response-bundle.profile.ttl.md) 

## Resource Profile: ReviseResponseBundle 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-revise-response-bundle | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:ReviseResponseBundle |

 
A Bundle that is used in the Client Registry response to Revise Patient requests. 

The RevisePatient FHIR Operation use the ReviseResponseBundle profile. The Bundle entries are all mandatory: a Patient, a Parameters, namely the MetadataParameters and OperationOutcome. Response meta data such as response creation time or response unique ID, etc, will be in the MetadataParameters resource. Any errors and warnings should be placed in the OperationOutcome.

**Usages:**

* Examples for this Profile: [Bundle/Revise-Response](Bundle-Revise-Response.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-revise-response-bundle)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 4 elements
 Must-Support: 7 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [ClientRegistryPatient(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient)](StructureDefinition-bc-patient.md)
* [MetadataParametersOut(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-out)](StructureDefinition-bc-metadata-parameters-out.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 4 elements
 Must-Support: 7 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [ClientRegistryPatient(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient)](StructureDefinition-bc-patient.md)
* [MetadataParametersOut(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-out)](StructureDefinition-bc-metadata-parameters-out.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 

Other representations of profile: [CSV](StructureDefinition-bc-revise-response-bundle.csv), [Excel](StructureDefinition-bc-revise-response-bundle.xlsx), [Schematron](StructureDefinition-bc-revise-response-bundle.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

