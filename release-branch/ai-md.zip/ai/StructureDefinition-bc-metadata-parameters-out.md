# MetadataParametersOut - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MetadataParametersOut**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-metadata-parameters-out-definitions.md) 
*  [Mappings](StructureDefinition-bc-metadata-parameters-out-mappings.md) 
*  [XML](StructureDefinition-bc-metadata-parameters-out.profile.xml.md) 
*  [JSON](StructureDefinition-bc-metadata-parameters-out.profile.json.md) 
*  [TTL](StructureDefinition-bc-metadata-parameters-out.profile.ttl.md) 

## Resource Profile: MetadataParametersOut 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-out | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:MetadataParametersOut |

 
Parameters profile for BC meta data - outbound messages. 

This profile of Parameters is intended for outbound messages. Each response (Operation) must have these fields in a Parameter resource. It also has a list of specific parameters that are common to all Operations, and common to all type of Messages (inbound, outbound, async). Below is a list of these parameters with descriptions.

| | |
| :--- | :--- |
| messageId | The unique id for the operation request. This is assigned by the sender of the operation request. |
| messageDateTime | DEPRECATED and Removed. This field was to store the date and time that the request was sent. |
| requestMessageId | Each request will have a response. The response can be related back to the request (important for asynchronous operations) when the unique Id of the request is included in the response. |
| sender | This is an identifier for the source of the request or response. |
| enterer | The user identifier if required. |

**Usages:**

* Use this Profile: [AddResponseBundle](StructureDefinition-bc-add-response-bundle.md), [MergeResponseBundle](StructureDefinition-bc-merge-response-bundle.md), [ReviseResponseBundle](StructureDefinition-bc-revise-response-bundle.md) and [SearchResponseBundle](StructureDefinition-bc-search-response-bundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-metadata-parameters-out)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Constraints

This structure is derived from [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md) 

**Summary**

Mandatory: 3 elements(1 nested mandatory element)
 Must-Support: 12 elements
 Prohibited: 8 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Parameters.parameter.value[x]

 **Key Elements View** 

#### Constraints

 **Differential View** 

This structure is derived from [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md) 

**Summary**

Mandatory: 3 elements(1 nested mandatory element)
 Must-Support: 12 elements
 Prohibited: 8 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Parameters.parameter.value[x]

 

Other representations of profile: [CSV](StructureDefinition-bc-metadata-parameters-out.csv), [Excel](StructureDefinition-bc-metadata-parameters-out.xlsx), [Schematron](StructureDefinition-bc-metadata-parameters-out.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

