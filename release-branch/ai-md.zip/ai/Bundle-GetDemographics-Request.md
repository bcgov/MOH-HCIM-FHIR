# GetDemographics-Request - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographics-Request**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-GetDemographics-Request.xml.md) 
*  [JSON](Bundle-GetDemographics-Request.json.md) 
*  [TTL](Bundle-GetDemographics-Request.ttl.md) 

## Example Bundle: GetDemographics-Request

Profile: [GetDemographicsRequestBundle](StructureDefinition-bc-get-demographics-request-bundle.md)

Bundle GetDemographics-Request of type collection

-------

Entry 1 - fullUrl = urn:uuid:289d85b9-43a4-4902-9b52-76cb1f02ea69

Resource Parameters:

> 

Profile: [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:72729b26-5d18-42e3-871a-ccfa9ba6ad06

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Anonymous Patient (no stated gender), DoB Unknown ( https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-mt-source-patient-id#8H1496LN8U1F17JP0H2VV)
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

