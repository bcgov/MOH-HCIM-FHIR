# BC Gender History - Testing - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Gender History**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-gender-history-extension.md) 
*  [Detailed Descriptions](StructureDefinition-bc-gender-history-extension-definitions.md) 
*  [Mappings](StructureDefinition-bc-gender-history-extension-mappings.md) 
*  [XML](StructureDefinition-bc-gender-history-extension.profile.xml.md) 
*  [JSON](StructureDefinition-bc-gender-history-extension.profile.json.md) 
*  [TTL](StructureDefinition-bc-gender-history-extension.profile.ttl.md) 

## Extension: GenderHistoryExtension - Testing

| |
| :--- |
| Active as of 2025-10-07 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

