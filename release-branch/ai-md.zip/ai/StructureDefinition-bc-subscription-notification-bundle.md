# SubscriptionNotificationBundle - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SubscriptionNotificationBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-subscription-notification-bundle-definitions.md) 
*  [Mappings](StructureDefinition-bc-subscription-notification-bundle-mappings.md) 
*  [XML](StructureDefinition-bc-subscription-notification-bundle.profile.xml.md) 
*  [JSON](StructureDefinition-bc-subscription-notification-bundle.profile.json.md) 
*  [TTL](StructureDefinition-bc-subscription-notification-bundle.profile.ttl.md) 

## Resource Profile: SubscriptionNotificationBundle 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-subscription-notification-bundle | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:SubscriptionNotificationBundle |

 
A Bundle that is used in the Client Registry when sending subscription notifications. 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-subscription-notification-bundle)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 4 elements
 Must-Support: 7 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [ClientRegistryPatient(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient)](StructureDefinition-bc-patient.md)
* [MetadataParametersSubscription(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-subscription)](StructureDefinition-bc-metadata-parameters-subscription.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 4 elements
 Must-Support: 7 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [ClientRegistryPatient(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-patient)](StructureDefinition-bc-patient.md)
* [MetadataParametersSubscription(http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-subscription)](StructureDefinition-bc-metadata-parameters-subscription.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 

Other representations of profile: [CSV](StructureDefinition-bc-subscription-notification-bundle.csv), [Excel](StructureDefinition-bc-subscription-notification-bundle.xlsx), [Schematron](StructureDefinition-bc-subscription-notification-bundle.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

