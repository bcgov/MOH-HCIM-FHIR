# Patient-GetDemographics-Example - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient-GetDemographics-Example**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Patient-Patient-GetDemographics-Example.xml.md) 
*  [JSON](Patient-Patient-GetDemographics-Example.json.md) 
*  [TTL](Patient-Patient-GetDemographics-Example.ttl.md) 

## Example Patient: Patient-GetDemographics-Example

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Jane Doe Female, DoB: 1972-10-16 ( Jurisdictional health number (use: official, period: 2000-01-01 11:11:11+0800 --> (ongoing)))

-------

| | |
| :--- | :--- |
| Contact Detail | * ph: 2505554848(Home)
* 721 FRONT ST VICTORIA BC V9A3Y3 CA 
 |

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

