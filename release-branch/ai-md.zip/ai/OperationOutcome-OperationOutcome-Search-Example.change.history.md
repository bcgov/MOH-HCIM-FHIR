#  - BC Client Registry FHIR Implementation Guide v1.0.0

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](OperationOutcome-OperationOutcome-Search-Example.md) 
*  [XML](OperationOutcome-OperationOutcome-Search-Example.xml.md) 
*  [JSON](OperationOutcome-OperationOutcome-Search-Example.json.md) 
*  [TTL](OperationOutcome-OperationOutcome-Search-Example.ttl.md) 

## : OperationOutcome/OperationOutcome-Search-Example - Change History

History of changes for OperationOutcome-Search-Example .

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

