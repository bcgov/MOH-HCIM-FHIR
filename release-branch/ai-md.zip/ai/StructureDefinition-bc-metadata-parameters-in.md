# MetadataParametersIn - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MetadataParametersIn**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-metadata-parameters-in-definitions.md) 
*  [Mappings](StructureDefinition-bc-metadata-parameters-in-mappings.md) 
*  [XML](StructureDefinition-bc-metadata-parameters-in.profile.xml.md) 
*  [JSON](StructureDefinition-bc-metadata-parameters-in.profile.json.md) 
*  [TTL](StructureDefinition-bc-metadata-parameters-in.profile.ttl.md) 

## Resource Profile: MetadataParametersIn 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameters-in | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:MetadataParametersIn |

 
Parameters profile for BC meta data - incoming messages. This profile is also intended to force the inclusion of specific parameters for the related Parameters. 

This profile of Parameters is intended for inbound messages. Each request (Operation) must have these fields in a Parameter resource. It also has a list of specific parameters that are common to all Operations, and common to all type of Messages (inbound, outbound, async). Below is a list of these parameters with descriptions.

| | |
| :--- | :--- |
| messageId | The unique id for the operation request. This is assigned by the sender of the operation request. |
| messageDateTime | DEPRECATED and Removed. This field was to store the date and time that the request was sent by the original sender |
| requestMessageId | Each request will have a response. The response can be related back to the request (important for asynchronous operations) when the unique Id of the request is included in the response. |
| sender | This is an identifier for the source of the request or response. |
| enterer | The user identifier if required. |

**Usages:**

* Derived from this Profile: [MetadataParametersAsync](StructureDefinition-bc-metadata-parameter-async-response.md) and [MetadataParametersOut](StructureDefinition-bc-metadata-parameters-out.md)
* Use this Profile: [AddRequestBundle](StructureDefinition-bc-add-request-bundle.md), [FindCandidatesRequestBundle](StructureDefinition-bc-find-candidates-request-bundle.md), [GetDemographicsRequestBundle](StructureDefinition-bc-get-demographics-request-bundle.md), [MergeRequestBundle](StructureDefinition-bc-merge-request-bundle.md) and [ReviseRequestBundle](StructureDefinition-bc-revise-request-bundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-metadata-parameters-in)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Constraints

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

**Summary**

Mandatory: 3 elements
 Must-Support: 7 elements
 Prohibited: 6 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Parameters.parameter

 **Key Elements View** 

#### Constraints

 **Differential View** 

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

**Summary**

Mandatory: 3 elements
 Must-Support: 7 elements
 Prohibited: 6 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Parameters.parameter

 

Other representations of profile: [CSV](StructureDefinition-bc-metadata-parameters-in.csv), [Excel](StructureDefinition-bc-metadata-parameters-in.xlsx), [Schematron](StructureDefinition-bc-metadata-parameters-in.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

