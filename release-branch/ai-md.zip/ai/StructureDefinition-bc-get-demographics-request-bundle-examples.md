# GetDemographicsRequestBundle - Examples - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographicsRequestBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-get-demographics-request-bundle.md) 
*  [Detailed Descriptions](StructureDefinition-bc-get-demographics-request-bundle-definitions.md) 
*  [Mappings](StructureDefinition-bc-get-demographics-request-bundle-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-bc-get-demographics-request-bundle.profile.xml.md) 
*  [JSON](StructureDefinition-bc-get-demographics-request-bundle.profile.json.md) 
*  [TTL](StructureDefinition-bc-get-demographics-request-bundle.profile.ttl.md) 

## Resource Profile: GetDemographicsRequestBundle - Examples

| |
| :--- |
| Active as of 2025-10-07 |

Examples for the bc-get-demographics-request-bundle Profile.

| |
| :--- |
| [GetDemographics-Request-By-SSRI](Bundle-GetDemographics-Request-By-SSRI.md) |
| [GetDemographics-Request](Bundle-GetDemographics-Request.md) |
| [GetDemographics-withHistory-Request](Bundle-GetDemographics-withHistory-Request.md) |

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

