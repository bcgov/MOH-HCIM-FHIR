# ReviseResponseBundle - Mappings - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ReviseResponseBundle**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-revise-response-bundle.md) 
*  [Detailed Descriptions](StructureDefinition-bc-revise-response-bundle-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-bc-revise-response-bundle-examples.md) 
*  [XML](StructureDefinition-bc-revise-response-bundle.profile.xml.md) 
*  [JSON](StructureDefinition-bc-revise-response-bundle.profile.json.md) 
*  [TTL](StructureDefinition-bc-revise-response-bundle.profile.ttl.md) 

## Resource Profile: ReviseResponseBundle - Mappings

| |
| :--- |
| Active as of 2025-10-07 |

Mappings for the bc-revise-response-bundle resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

