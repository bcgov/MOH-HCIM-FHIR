# ClientRegistryPatient - Examples - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ClientRegistryPatient**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](StructureDefinition-bc-patient.md) 
*  [Detailed Descriptions](StructureDefinition-bc-patient-definitions.md) 
*  [Mappings](StructureDefinition-bc-patient-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-bc-patient.profile.xml.md) 
*  [JSON](StructureDefinition-bc-patient.profile.json.md) 
*  [TTL](StructureDefinition-bc-patient.profile.ttl.md) 

## Resource Profile: ClientRegistryPatient - Examples

| |
| :--- |
| Active as of 2025-10-07 |

Examples for the bc-patient Profile.

| |
| :--- |
| [Force-Create-Request](Patient-Force-Create-Request.md) |
| [Newborn-Request](Patient-Newborn-Request.md) |
| [Patient-GetDemographics-Example](Patient-Patient-GetDemographics-Example.md) |
| [Revise-Request-No-SRI-RESTful](Patient-Revise-Request-No-SRI-RESTful.md) |
| [Revise-Request](Patient-Revise-Request.md) |

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

