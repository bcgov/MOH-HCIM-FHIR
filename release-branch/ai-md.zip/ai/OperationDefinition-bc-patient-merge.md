# Merge Patient - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Merge Patient**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](OperationDefinition-bc-patient-merge.xml.md) 
*  [JSON](OperationDefinition-bc-patient-merge.json.md) 
*  [TTL](OperationDefinition-bc-patient-merge.ttl.md) 

## OperationDefinition: Merge Patient 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/OperationDefinition/bc-patient-merge | *Version*:1.0.0 |
| Draft as of 2025-10-07 | *Computable Name*:MergePatient |

 
This operation is used to merge patients. 

The merge operation is used to request two patient resources be merged. One of the two patients is identified as the source (non-survivor) and on as the target (survivor). The data from the source patient will be merged with the data of the target patient.

The source Patient resource will be updated to add a new Patient.link reference to the target Patient resource with a link-type of replaced-by. The source Patient will also be updated to have a status of inactive, unless the source Patient resource was deleted.

The target Patient resource will be updated to add a new Patient.link reference to the source Patient resource with a link-type of replaces unless the source Patient resource is deleted. The target Patient resource must be included in the result-patient paramter if used.

URL: [base]/Patient/$merge

Input parameters Profile:[Parameters](http://hl7.org/fhir/R4/parameters.html)

Output parameters Profile:[Parameters](http://hl7.org/fhir/R4/parameters.html)

### Parameters

* **Use**: IN
  * **Name**: source-patient
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [Reference](http://hl7.org/fhir/R4/references.html#Reference)
  * **Binding**: 
  * **Documentation**: A direct resource reference to the source patient resource (this may include an identifier).
* **Use**: IN
  * **Name**: source-patient-identifier
  * **Scope**: 
  * **Cardinality**: 0..*
  * **Type**: [Identifier](http://hl7.org/fhir/R4/datatypes.html#Identifier)
  * **Binding**: 
  * **Documentation**: When source-patient-identifiers are provided, the server is expected to perform an internal lookup to identify the source patient record. The server SHALL reject the request if the provided identifiers do not resolve to a single patient record. This resolution MAY occur asynchronously, for example, as a part of a review by a user.
* **Use**: IN
  * **Name**: target-patient
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [Reference](http://hl7.org/fhir/R4/references.html#Reference)
  * **Binding**: 
  * **Documentation**: A direct resource reference to the target patient resource. This is the surviving patient resource, the target for the merge.
* **Use**: IN
  * **Name**: target-patient-identifier
  * **Scope**: 
  * **Cardinality**: 0..*
  * **Type**: [Identifier](http://hl7.org/fhir/R4/datatypes.html#Identifier)
  * **Binding**: 
  * **Documentation**: When target-patient-identifiers are provided, the server is expected to perform an internal lookup to identify the target patient record. The server SHALL reject the request if the provided identifiers do not resolve to a single patient record. This resolution MAY occur asynchronously, for example, as a part of a review by a user.
* **Use**: IN
  * **Name**: result-patient
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [Patient](http://hl7.org/fhir/R4/patient.html)
  * **Binding**: 
  * **Documentation**: The details of the Patient resource that is expected to be updated to complete with and must have the same patient.id and provided identifiers included. This resource MUST have the link property included referencing the source patient resource. It will be used to perform an update on the target patient resource. In the absence of this parameter the servers should copy all identifiers from the source patient into the target patient, and include the link property. This is often used when properties from the source patient are desired to be included in the target resource. The receiving system may also apply other internal business rules onto the merge which may make the resource different from what is provided here.
* **Use**: OUT
  * **Name**: return
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [Parameters](http://hl7.org/fhir/R4/parameters.html)
  * **Binding**: 
  * **Documentation**: The Parameters resource will include: The Input parameters to the operation, An OperationOutcome containing errors, warnings, and information messages, The resulting merged Patient resource (or a patient reference if the patient is not committed), Optionally a Task resource to track any additional processing that was required.

### Notes:

The FHIR Mimic R5 Merge Person feature is one that modifies the format of the existing R4 Merge Person interface so that it aligns closely with the R5 version of the FHIR specifications.

Some of the differences include:

* Identifier in the Parameters (source-patient-identifier) needs to include the [merge-status-extension](StructureDefinition-bc-merge-status-extension.md)
* Preview parameter is not allowed
* Merge Patient identifiers its own value set that allows official, secondary and old. Old will indicate non-survivors in the patient in the result-patient and only for merge patients.

#### Examples

See [Merge Patient request](Parameters-Merge-Request.md) example. See [Merge Patient response](Parameters-Merge-Response.md) example.

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

