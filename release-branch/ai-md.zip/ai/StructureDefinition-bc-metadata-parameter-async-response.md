# MetadataParametersAsync - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MetadataParametersAsync**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-bc-metadata-parameter-async-response-definitions.md) 
*  [Mappings](StructureDefinition-bc-metadata-parameter-async-response-mappings.md) 
*  [XML](StructureDefinition-bc-metadata-parameter-async-response.profile.xml.md) 
*  [JSON](StructureDefinition-bc-metadata-parameter-async-response.profile.json.md) 
*  [TTL](StructureDefinition-bc-metadata-parameter-async-response.profile.ttl.md) 

## Resource Profile: MetadataParametersAsync 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/StructureDefinition/bc-metadata-parameter-async-response | *Version*:1.0.0 |
| Draft as of 2025-10-07 | *Computable Name*:MetadataParametersAsync |

 
Parameters profile for BC meta data - async messages. 

This profile of Parameters is intended for asynchronous responses. Each asynchronous response message must have these fields in a Parameter resource. It also has a list of specific parameters that are common to all Operations, and common to all type of Messages (inbound, outbound, async). Below is a list of these parameters with descriptions.

| | |
| :--- | :--- |
| messageId | The unique id for the operation request. This is assigned by the sender of the operation request. |
| messageDateTime | DEPRECATED and Removed. This field was to store the date and time that the request was sent by the original sender |
| requestMessageId | Each request will have a response. The response can be related back to the request (important for asynchronous operations) when the unique Id of the request is included in the response. |
| sender | This is an identifier for the source of the request or response. |
| enterer | The user identifier if required. |

**Usages:**

* Use this Profile: [AsyncAckBundle](StructureDefinition-bc-async-ack-response-bundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.ca-bc.client|current/StructureDefinition/bc-metadata-parameter-async-response)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Constraints

This structure is derived from [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md) 

**Summary**

Mandatory: 3 elements(1 nested mandatory element)
 Must-Support: 12 elements
 Prohibited: 8 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Parameters.parameter.value[x]

 **Key Elements View** 

#### Constraints

 **Differential View** 

This structure is derived from [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md) 

**Summary**

Mandatory: 3 elements(1 nested mandatory element)
 Must-Support: 12 elements
 Prohibited: 8 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Parameters.parameter.value[x]

 

Other representations of profile: [CSV](StructureDefinition-bc-metadata-parameter-async-response.csv), [Excel](StructureDefinition-bc-metadata-parameter-async-response.xlsx), [Schematron](StructureDefinition-bc-metadata-parameter-async-response.sch) 

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

