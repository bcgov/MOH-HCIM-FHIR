# BC Address Validation Value Set - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC Address Validation Value Set**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](ValueSet-bc-address-validation-value-set.xml.md) 
*  [JSON](ValueSet-bc-address-validation-value-set.json.md) 
*  [TTL](ValueSet-bc-address-validation-value-set.ttl.md) 

## ValueSet: BC Address Validation Value Set 

| | |
| :--- | :--- |
| *Official URL*:https://terminology.hlth.gov.bc.ca/ClientRegistry/ValueSet/bc-address-validation-value-set | *Version*:1.0.0 |
| Active as of 2025-10-07 | *Computable Name*:AddressValidationVS |

 
BC Address Validation value set used to describe the validation status of an address 

 **References** 

* [BC Address Validation Status Code](StructureDefinition-bc-validation-status-extension.md)

### Logical Definition (CLD)

* Include all codes defined in [`https://terminology.hlth.gov.bc.ca/ClientRegistry/CodeSystem/bc-client-registry-address-validation-code-system`](CodeSystem-bc-client-registry-address-validation-code-system.md) version 📦1.0.0

 

### Expansion

Expansion performed internally based on [codesystem BC Client Registry Address Validation Status Code v1.0.0 (CodeSystem)](CodeSystem-bc-client-registry-address-validation-code-system.md)

This value set contains 3 concepts

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

