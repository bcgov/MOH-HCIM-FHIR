# BC HCIM Client Capability Statement - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BC HCIM Client Capability Statement**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](CapabilityStatement-bc-hcim-capability-statement-client.xml.md) 
*  [JSON](CapabilityStatement-bc-hcim-capability-statement-client.json.md) 
*  [TTL](CapabilityStatement-bc-hcim-capability-statement-client.ttl.md) 

## CapabilityStatement: BC HCIM Client Capability Statement 

| | |
| :--- | :--- |
| *Official URL*:http://hlth.gov.bc.ca/fhir/client/CapabilityStatement/bc-hcim-capability-statement-client | *Version*:1.0.0 |
| Draft as of 2021-11-18 | *Computable Name*:HCIMClientCapabilityStatement |

 
This capability statement describes the use cases that are supported by the BC FHIR implementation of the Client Registry when it is acting as a client. I.e. sending notifications - FUTURE work. 

 [Raw OpenAPI-Swagger Definition file](bc-hcim-capability-statement-client.openapi.json) | [Download](bc-hcim-capability-statement-client.openapi.json) 

## BC HCIM Client Capability Statement

* Implementation Guide Version: 1.0.0 
* FHIR Version: 4.0.1 
* Supported Formats: `json`
* Published on: 2021-11-18 
* Published by: BC Ministry of Health 

> **Note to Implementers: FHIR Capabilities**Any FHIR capability may be 'allowed' by the system unless explicitly marked as 'SHALL NOT'. A few items are marked as MAY in the Implementation Guide to highlight their potential relevance to the use case.

## FHIR RESTful Capabilities

### Mode: client

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

