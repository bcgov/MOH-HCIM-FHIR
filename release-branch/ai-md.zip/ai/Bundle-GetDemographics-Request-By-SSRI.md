# GetDemographics-Request-By-SSRI - BC Client Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GetDemographics-Request-By-SSRI**

BC Client Registry FHIR Implementation Guide - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hlth.gov.bc.ca/fhir/client/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-GetDemographics-Request-By-SSRI.xml.md) 
*  [JSON](Bundle-GetDemographics-Request-By-SSRI.json.md) 
*  [TTL](Bundle-GetDemographics-Request-By-SSRI.ttl.md) 

## Example Bundle: GetDemographics-Request-By-SSRI

Profile: [GetDemographicsRequestBundle](StructureDefinition-bc-get-demographics-request-bundle.md)

Bundle GetDemographics-Request-By-SSRI of type collection

-------

Entry 1 - fullUrl = urn:uuid:f38e3ec9-9b39-4d2a-b8e5-0471ae234dda

Resource Parameters:

> 

Profile: [MetadataParametersIn](StructureDefinition-bc-metadata-parameters-in.md)

## Parameters


-------

Entry 2 - fullUrl = urn:uuid:8ef35b62-3ed8-4caa-8bed-c0cff5b72738

Resource Patient:

> 

Profile: [ClientRegistryPatient](StructureDefinition-bc-patient.md)

Anonymous Patient (no stated gender), DoB Unknown ( https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-fha-exp-source-patient-id#MB220FXR155686125TUN (use: official, ))
-------

 IG © 2022+ [BC Ministry of Health](https://www2.gov.bc.ca/gov/content/governments/organizational-structure/ministries-organizations/ministries/health). Package fhir.ca-bc.client#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

